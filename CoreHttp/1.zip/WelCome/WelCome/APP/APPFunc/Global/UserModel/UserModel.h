//
//  UserModel.h
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreArchiveHeader.h"
#import "CoreArchive.h"
#import "BaseModel.h"
#import <UIKit/UIKit.h>

@interface UserModel : NSObject

@property (nonatomic,copy) NSString *lailai_id,*phone,*token,*name,*weixin,*qq,*photo,*addressName;

@property (nonatomic,assign) NSInteger vip,nowOrder,historyOrder,addressID,sex;

@property (nonatomic,copy) NSString *sexStr;

@property (nonatomic,strong) UIImage *headImage;

CoreArchiver_MODEL_H



@end
