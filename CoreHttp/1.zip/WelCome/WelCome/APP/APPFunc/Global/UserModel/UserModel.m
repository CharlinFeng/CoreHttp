//
//  UserModel.m
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

CoreArchiver_MODEL_M

-(NSString *)sexStr{
    return @[@"未知",@"男",@"女"][self.sex];
}

+(NSArray *)ignoredCodingPropertyNames{
    return @[@"headImage"];
}

@end
