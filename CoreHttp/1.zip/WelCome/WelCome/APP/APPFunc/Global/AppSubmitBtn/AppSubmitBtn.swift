//
//  AppSubmitBtn.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class AppSubmitBtn: CoreStatusBtn {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    /** 视图准备 */
    func viewPrepare(){
        
        self.backgroundColorForNormal = hexColor("e94e50")
        self.backgroundColorForHighlighted = hexColor("ae2224")
        self.radius = 4
    }
    

}
