//
//  AppHost.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/22.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

/** 资源 */
let HOST_RESOURCE_URL = "http://211.149.151.92/"

/** 服务器主地址 */
let HOST_URL = HOST_RESOURCE_URL + "lailai/"





/** 获取验证码 */
let URL_GET_CODE = "MyApi/sendSms"

/** 注册 */
let URL_REGISTER = "MyApi/userPwd"

/** 登陆 */
let URL_LOGIN = "MyApi/login"


/** 退出登陆 */
let URL_LOGOUT = "MyApi/logout"


/** 修改手机 */
let URL_MODIFY_MOBILE = "MyApi/updataPhone"


/** 修改密码 */
let URL_MODIFY_PWD = "MyApi/updataPwd"


/** 用户协议 */
let URL_USER_PROTOCOL = HOST_RESOURCE_URL + "webpage/come_agreement.html"


/** 修改用户资料 */
let URL_MODIFY_USER_DATA = "MyApi/updataUser"


/** 意见反馈 */
let URL_FEEDBACK = "MyApi/feedback"


/** 升级VIP */
let URL_UPGRADE_VIP = "MyApi/upgradeVip"


/** 发现列表 */
let URL_DISCOVER = "MyApi/discover"


/** 服务人员列表 */
let URL_SERVICE_LSIT = "MyApi/findTranslator"


/** 翻译 */
let URL_LANG = "MyApi/language"


/** 服务人员详情 */
let URL_SERVICE_DETAIL = "MyApi/staffInfo"


/** 收藏 */
let URL_COLLECTION = "MyApi/collectStaff"


/** 提交订单 */
let URL_SUBMIT_ORDER = "MyApi/submitOrder"



/** 取消订单 */
let URL_CANCEL_ORDER = "MyApi/cancelOrder"


/** 获取订单数据 */
let URL_COUNT_ORDER = "MyApi/userOrder"


/** 修改昵称 */
let URL_MODIFY_NICK = "MyApi/updataName"


