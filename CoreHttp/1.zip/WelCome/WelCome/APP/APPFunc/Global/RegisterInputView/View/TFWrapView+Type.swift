//
//  TFWrapView+Type.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension TFWrapView{
    
    enum TFWrapViewType{
        
        /** 无类型 */
        case None
        
        /** 纯图片 */
        case Image(imageName: String , ph: String)
        
        /** 手机类 */
        case Mobile(btnTag: Int)
        
        /** 文本：无边线 */
        case Text(text: String)
        
        /** 文本：有边线 */
        case TextWithBorder(text: String)
        
    }
    
    
    
    
}