//
//  TFWrapView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class TFWrapView: UIView {
    
    static let itemH: CGFloat = 46
    
    
    
    
    @IBOutlet weak var imageV: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var verifyBtn: UIButton!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var leftContentView: UIView!
    
    
    


    var type: TFWrapViewType!
    var hasBottomBorder = NO
    
    

    private let GrayColor = hexColor("e0e1e1")
    
    
    override func awakeFromNib() {
        verifyBtn.radius = 4
    }
    
    class func wrapViewWithRegisterModel(registerModel: RegisterInputModel) -> TFWrapView{
        
        //创建视图
        let wrapView = self.viewFromXIB()
        
        //设置数据
        wrapView.handleViewWithType(registerModel.type, hasBottomBorder: registerModel.hasBottomBorder)
        
        return wrapView
    }
    
    
    func handleViewWithType(type: TFWrapViewType,hasBottomBorder: Bool){
        
        self.type = type
        self.hasBottomBorder = hasBottomBorder
        
        /** 定制界面 */
        custormUI()
        
        //添加底部线条
        if !hasBottomBorder {return}
        contentView.addSingleBorder(UIViewBorderDirectBottom, color: GrayColor, width: 1.0)
    }
    

    
    /** 定制界面 */
    func custormUI(){
        
        switch type! {
            
            //无类型
            case TFWrapViewType.None:
            assertionFailure("请指定类型")
        
            //图片模式
            case let TFWrapViewType.Image(imageName, ph):
            imageModel(imageName, ph: ph)
            
            /** 手机类 */
            case let .Mobile(tag):
            mobileModel(tag)
            
            /** 文本：无边线 */
            case let .Text(text):
            textModel(text)
            
            /** 文本：有边线 */
            case let .TextWithBorder(text):
            textWithBorderModel(text)
            
        }
        
        
    }
    
    /** 处理图片模式 */
    func imageModel(imageName: String, ph: String){
        
        //隐藏label
        label.hidden = YES
        //隐藏btn
        verifyBtn.hidden = YES
        
        //设置图片
        imageV.image = UIImage(named: imageName)
        //占位文字
        textField.placeholder = ph
    }
    
    /** 处理手机模式 */
    func mobileModel(tag: Int){
        
        //隐藏图片
        imageV.hidden = YES
        
        //设置label文字
        label.text = "+86"
        
        //leftContentView加边线
        leftContentView.addSingleBorder(UIViewBorderDirectRight, color: GrayColor, width: 1)
        
        //占位
        textField.placeholder = "手机号"
        
        //绘制边框
        verifyBtn.border(width: 1, color: GrayColor)
        
        //btn设置tag
        verifyBtn.tag = tag
    }
    
    /** 处理文本：无边线模式 */
    func textModel(text: String){
        
        //隐藏图片
        imageV.hidden = YES
        //隐藏按钮
        verifyBtn.hidden = YES
        //设置文字
        label.text = text
        textField.placeholder = text
    }
    
    /** 处理文本：有边线模式 */
    func textWithBorderModel(text: String){
        
        textModel(text)
        
        //添加边线
        leftContentView.addSingleBorder(UIViewBorderDirectRight, color: GrayColor, width: 1)
    }
    
    
    @IBAction func clickVerfyBtn(sender: AnyObject) {
        
        //发送通知
        NSNotificationCenter.defaultCenter().postNotificationName(RegisterBtnClickNoti, object: sender)
        
    }
    
    
    
    
    
}
