//
//  RegisterInputModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


class RegisterInputModel {
    
    let type: TFWrapView.TFWrapViewType
    let hasBottomBorder: Bool
    
    init(type: TFWrapView.TFWrapViewType, hasBottomBorder: Bool){
        
        self.type = type
        self.hasBottomBorder = hasBottomBorder
    }
}