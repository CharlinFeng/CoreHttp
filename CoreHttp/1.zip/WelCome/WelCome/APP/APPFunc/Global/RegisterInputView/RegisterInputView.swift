//
//  RegisterInputView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class RegisterInputView: UIView {

    
    var wrapViews: [TFWrapView]!{
        didSet{showTFWarpView()}
    }
    
    
    /** TFWarpView数据展现与布局 */
    func showTFWarpView(){
        
        if wrapViews == nil {return}
        
        let height = TFWrapView.itemH
        
        //遍历创建
        wrapViews.enumerate { (index, tfWarpView) -> Void in
            
            //添加
            self.addSubview(tfWarpView)

            //添加约束
            tfWarpView.snp_makeConstraints({ (make) -> Void in
                
                //高
                make.height.equalTo(height)
                
                //左
                make.left.equalTo(tfWarpView.superview!.snp_left)
                
                //右
                make.right.equalTo(tfWarpView.superview!.snp_right)
                
                //上
                make.top.equalTo(tfWarpView.superview!.snp_top).offset(height * index)
                
            })

        }
    }
    
    
    

}
