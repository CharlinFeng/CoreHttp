//
//  IconView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/16.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class IconView: UIView {

    /** 更新界面 */
    func showIcon(icon: String?,isVip: Bool){
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            
            if icon != nil {self.imageView.image = UIImage(named: icon!)}
            
            self.vipImageV.hidden = !isVip
        })
    }
    
    var isVip: Bool = NO {
        
        didSet{
        
        
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                self.vipImageV.hidden = !self.isVip
            })
        }
        
    }
    
    /** icon视图 */
    var imageView: UIImageView!
    
    /** vip */
    private var vipImageV: UIImageView!
    
    override func awakeFromNib() {
        
        
        
        self.backgroundColor = UIColor.clearColor()
        
        let width: CGFloat = 26
        let height: CGFloat = 18
        
        //创建imageView
        
        let imageV = UIImageView(image: UIImage(named: "defaultPhoto"))

        self.imageView = imageV
    
        //添加
        self.addSubview(imageV)
        
        //添加约束
        imageV.make_4Insets(UIEdgeInsetsMake(height * 0.5, width * 0.5, height * 0.5, width * 0.5))
        imageV.clipsToBounds = YES
        imageV.layer.masksToBounds = YES
        imageV.contentMode = UIViewContentMode.ScaleAspectFit
        imageV.setBorder(rgb(214, 214, 214, 1), width: 0.5)
        imageV.layer.cornerRadius = 8
        imageV.layer.masksToBounds = YES
        
        //创建Vip图片
        let vipImageV = UIImageView(image: UIImage(named: "iconVIP")?.imageWithGradientTintColor(AppConst.AppColor))
        self.vipImageV = vipImageV
        
        //默认不显示
        vipImageV.hidden = YES
        
        //添加
        self.addSubview(vipImageV)
        
        //添加约束
        vipImageV.snp_makeConstraints { (make) -> Void in
            
            make.size.equalTo(CGSizeMake(width, height))
            make.leading.equalTo(0)
            make.top.equalTo(0)
        }
        
    }
    
    
    
    
    
}
