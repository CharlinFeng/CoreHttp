//
//  APPConst.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


let RegisterBtnClickNoti = "RegisterBtnClickNoti"

let LoginSuccessNoti = "LoginSuccessNoti"
let LogoutSuccessNoti = "LogoutSuccessNoti"


/** 全局定义：兼容OC */
public class AppConst: NSObject{
    
    /** 全局颜色 */
    static let AppColor = hexColor("fe5454")
    
    /** 服务器地址 */
    static let HostAddr = "http://211.149.151.92/lailai/"
    
    /** 资源地址 */
    static let ResourceAddr = "http://211.149.151.92/"
    
    /** 首页幻灯 */
    static let IndexShow = "MyApi/slide"
}












