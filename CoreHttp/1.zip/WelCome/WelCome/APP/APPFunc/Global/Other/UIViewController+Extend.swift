//
//  UIViewController+Extend.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/14.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension UIViewController{
    
    
    /** 添加关闭按钮 */
    func addDismissBarButton(){
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(size: CGSizeMake(24, 24), target: self, selector: "dismissAction", imgName: "cancel", hlImageColor: UIColor.grayColor())
    }
    
    func dismissAction(){
        
        self.dismissViewControllerAnimated(YES, completion: nil)
    }
    
    
    
}