//
//  AppCityModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


let AppCityModelGetedCityNoti = "AppCityModelGetedCityNoti"

@objc class AppCityModel {
    
    var isLocatedCity: Bool = NO
    
    var currentCityModel: CFCityPickerVC.CityModel = CFCityPickerVC.CityModel(id: 2182, pid: 2181, name: "成都", spell: "ChengDu") {didSet{getedCity()}}
    
    lazy var cityModels: [CFCityPickerVC.CityModel] = {self.cityModelsPrepare()}()
    
    class var sharedInstance : AppCityModel {
    
    struct Static {
    
    static let instance : AppCityModel = AppCityModel()
    }
    
    return Static.instance
    }
    
    let location = LocationManager.sharedInstance
    
    func getCurrentCityForOC()->Int{return currentCityModel.id}
    
    
    /** 获取当前城市模型 */
    func getCurrentCityModel(){
        
        //自动定位
        location.autoUpdate = YES
        
        //开始定位
        location.startUpdatingLocationWithCompletionHandler {[unowned self] (latitude, longitude, status, verboseMessage, error) -> () in
            
            self.location.stopUpdatingLocation()
            
            //反地理编码
            self.location.reverseGeocodeLocationWithLatLon(latitude: latitude, longitude: longitude, onReverseGeocodingCompletionHandler: { (reverseGecodeInfo, placemark, error) -> Void in
                
                if error != nil {return}
                if placemark == nil {return}
                
                var city: String = (placemark!.locality as NSString).stringByReplacingOccurrencesOfString("市", withString: "")
                
                //获取城市模型
                let cityModel = CFCityPickerVC.CityModel.findCityModelWithCityName([city], cityModels: self.cityModels, isFuzzy: NO)?.first
                
                if cityModel != nil {self.currentCityModel = cityModel!}
                
            })
        }
        
    }
    
    
    
    /** 获取到城市 */
    func getedCity(){
        
        NSNotificationCenter.defaultCenter().postNotificationName(AppCityModelGetedCityNoti, object: self, userInfo: ["cityModel":self.currentCityModel])
        self.isLocatedCity = YES
        
        
    }
}



/** 这里是无关的解析业务 */
extension AppCityModel{
    
    /** 解析字典数据，由于swift中字典转模型工具不完善，这里先手动处理 */
    func cityModelsPrepare() -> [CFCityPickerVC.CityModel]{
        
        //加载plist，你也可以加载网络数据
        let plistUrl = NSBundle.mainBundle().URLForResource("City", withExtension: "plist")!
        let cityArray = NSArray(contentsOfURL: plistUrl) as! [NSDictionary]
        
        var cityModels: [CFCityPickerVC.CityModel] = []
        
        for dict in cityArray{
            let cityModel = parse(dict)
            cityModels.append(cityModel)
        }
        
        return cityModels
    }
    
    func parse(dict: NSDictionary) -> CFCityPickerVC.CityModel{
        
        let id = dict["id"] as! Int
        let pid = dict["pid"] as! Int
        let name = dict["name"] as! String
        let spell = dict["spell"] as! String
        
        let cityModel = CFCityPickerVC.CityModel(id: id, pid: pid, name: name, spell: spell)
        
        let children = dict["children"]
        
        if children != nil { //有子级
            
            var childrenArr: [CFCityPickerVC.CityModel] = []
            for childDict in children as! NSArray {
                
                let childrencityModel = parse(childDict as! NSDictionary)
                
                childrenArr.append(childrencityModel)
            }
            
            cityModel.children = childrenArr
        }
        
        
        return cityModel
    }
    
}
