//
//  ShowVC+JazzHands.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/9.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension ShowVC{
    
    var screenCount: Int {return 5}
    var screenWidth: CGFloat {return self.view.width}
    
    /** 专门处理手势帧动画 */
    func jassHandzPrepare(){
        
        if isHandledJazzHands { return}
        
        /** 太阳 */
        self.sunMove()
        
        /** 云朵 */
        self.cloudMove()
        
        /** 飞机 */
        self.airMove()
        
        /** 第二屏的人开始运动 */
        self.man2Move()
        
        /** 第三屏妹子先缩小、再移动 */
        self.girl3ZoomIn()
        
        /** 第三屏的灯 */
        self.bulb3Display()
        
        /** 第四屏的面板 */
        self.board4Display()
        
        /** 最后一屏的两个人一边人上向下运动，一边放大 */
        self.hanld5Move()
        
        isHandledJazzHands = YES
    }
    
    
    /** 太阳 */
    func sunMove(){
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:sunLeftC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            let kf0 = JHKeyFrameModel.kfm(0, value: ^self.sunLeftC.constant)
            
            let kf1Time = Int((self.screenCount - 2).toCGFloat * self.screenWidth)
            let kf1Value = CGFloat(kf1Time)
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time, value: ^kf1Value)
            
            return [kf0,kf1]
        }
    }
    
    /** 云朵 */
    func cloudMove(){
        
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:cloudLeftC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            let kf0 = JHKeyFrameModel.kfm(0, value: ^self.cloudLeftC.constant)
            
            let kf1Time = Int((self.screenCount - 2).toCGFloat * self.screenWidth*0.99)
            let kf1Value = CGFloat(kf1Time)
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time, value: ^kf1Value)
            
            return [kf0,kf1]
        }
        
    }
    
    /** 飞机 */
    func airMove(){
        
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:airLeftC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var leftMargin = self.airLeftC.constant
            
            let kf0 = JHKeyFrameModel.kfm(0, value: ^leftMargin)
            
            let kf1 = JHKeyFrameModel.kfm(Int(self.screenWidth), value: ^1000)
            
            return [kf0,kf1]
        }
        
    }
    
    /** 第二屏的人开始运动 */
    func man2Move(){
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:manLeadingC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^self.manLeadingC.constant)
            
            let kf1Time = Int((self.screenCount - 3).toCGFloat * self.screenWidth*0.99)
            
            var endValue = self.screenWidth * 1.1
            
 
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time, value: ^endValue)
            
            return [kf0,kf1]
        }
        
        
        if iOS7() {return}
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:self.woman2BottomC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var bottomConstant = self.woman2BottomC.constant
            let marginBegin: CGFloat = 20
            var marginEnd: CGFloat = 10
            if(iPhone6_375_667()){marginEnd = -50}
            
            var kf0Time = self.screenWidth * 2
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^(bottomConstant - marginBegin))
            
            let kf1Time = Int((self.screenCount - 4).toCGFloat * self.screenWidth)
            
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time, value: ^(bottomConstant + marginEnd))
            
            return [kf0,kf1]
        }

    }
    
    /** 第三屏妹子先缩小、再移动 */
    func girl3ZoomIn(){
        
        self.jazzHands_frameHand(girlView, animType: JazzHandsAnimTypeScale,constraint:nil) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 2
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^0.72)
            
            var kf1Time = self.screenWidth * 3
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^1)
            
            return [kf0,kf1]
        }
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:girlTrailingC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 2
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^self.girlTrailingC.constant)
            
            let kf1Time = self.screenWidth * 3
            
            let kf1Value = self.screenWidth * 0.95
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^kf1Value)
            
            return [kf0,kf1]
        }
        
        
        if(iPhone4x_320_480() || iPhone5x_320_568()) { return}
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:self.woman2BottomC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 2
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^100)
            
            let kf1Time = self.screenWidth * 3
            
            let kf1Value = self.screenWidth * 0.95
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^130)
            
            return [kf0,kf1]
        }
        
        
        
    }
    
    
    /** 第三屏的灯 */
    func bulb3Display(){
        
        self.jazzHands_frameHand(bulb, animType: JazzHandsAnimTypeAlpha,constraint:nil) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            let alpha0 = 0
            let alpha1 = 1
            
            var margin: CGFloat = 10
            
            var kf0Time = self.screenWidth * 2 - margin
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^alpha0)
            
            let kf1Time = kf0Time + margin
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^alpha1)
            
            let kf2Time = kf0Time + margin * 2
            
            let kf2 = JHKeyFrameModel.kfm(kf2Time.toInt, value: ^alpha0)
            
            return [kf0,kf1,kf2]
        }
        
    }
    
    
    /** 第四屏的面板 */
    func board4Display(){
        
        self.jazzHands_frameHand(guideBoard, animType: JazzHandsAnimTypeAlpha,constraint:nil) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            let alpha0 = 0
            let alpha1 = 1
            
            var margin: CGFloat = 20
            
            var kf0Time = self.screenWidth * 3 - margin
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^alpha0)
            
            let kf1Time = kf0Time + margin
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^alpha1)
            
            let kf2Time = kf0Time + margin * 3
            
            let kf2 = JHKeyFrameModel.kfm(kf2Time.toInt, value: ^alpha0)
            
            return [kf0,kf1,kf2]
        }
        
    }
    
    /** 最后一屏的两个人一边人上向下运动，一边放大 */
    func hanld5Move(){
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:handClashBottomC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 3.4
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^200)
            
            let kf1Time =  self.screenWidth * 4
            
            var bottomV = self.handClashBottomC.constant
            
            if( iPhone6_375_667() ) {bottomV += 20}
            if( iPhone6Plus_414_736_Portait()) {bottomV += 40}
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^bottomV)
            
            return [kf0,kf1]
        }
        
        self.jazzHands_frameHand(handClasp, animType: JazzHandsAnimTypeScale,constraint:handClashBottomC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 3.4
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^0)
            
            let kf1Time =  self.screenWidth * 4
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^1)
            
            return [kf0,kf1]
        }
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:handLeadingC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 3.4
            
            var leftValue = -50
            
            if(!iOS7()) {leftValue = 0}
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^(leftValue))
            
            let kf1Time =  self.screenWidth * 4
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^self.handLeadingC.constant)
            
            return [kf0,kf1]
        }
        
        /** 按钮 */
        self.jazzHands_frameHand(enterBtn, animType: JazzHandsAnimTypeAlpha,constraint:nil) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            let alpha0 = 0
            let alpha1 = 1
            
            var margin: CGFloat = 50
            
            var kf0Time = self.screenWidth * 4 - margin
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^alpha0)
            
            let kf1Time = kf0Time + margin
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^alpha1)
            
            let kf2Time = kf0Time + margin
            
            let kf2 = JHKeyFrameModel.kfm(kf2Time.toInt, value: ^alpha0)
            
            return [kf0,kf1,kf2]
        }
        
        
        self.jazzHands_frameHand(nil, animType: JazzHandsAnimTypeConstraints,constraint:logoTopC) { (animation IFTTTAnimation) -> [AnyObject]! in
            
            var kf0Time = self.screenWidth * 3.4
            
            let kf0 = JHKeyFrameModel.kfm(kf0Time.toInt, value: ^(-80))
            
            let kf1Time =  self.screenWidth * 4
            
            var endValue: CGFloat = self.logoTopC.constant
            
            if iPhone4x_320_480() {endValue = 10}
            
            let kf1 = JHKeyFrameModel.kfm(kf1Time.toInt, value: ^endValue)
            
            return [kf0,kf1]
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
}