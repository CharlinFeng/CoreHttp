//
//  ShowVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit


class ShowVC: CoreJazzHandsVC,UIScrollViewDelegate {
    
    
    /** JazzHansz专区 */
    
    @IBOutlet weak var sunLeftC: NSLayoutConstraint!
    @IBOutlet weak var cloudLeftC: NSLayoutConstraint!
    @IBOutlet weak var airLeftC: NSLayoutConstraint!
    @IBOutlet weak var manLeadingC: NSLayoutConstraint!
    @IBOutlet weak var girlView: UIImageView!
    @IBOutlet weak var girlTrailingC: NSLayoutConstraint!
    @IBOutlet weak var bulb: UIImageView!
    @IBOutlet weak var guideBoard: UIImageView!
    @IBOutlet weak var handClasp: UIImageView!
    @IBOutlet weak var handClashBottomC: NSLayoutConstraint!
    @IBOutlet weak var handLeadingC: NSLayoutConstraint!
    @IBOutlet weak var enterBtn: CoreBtn!
    @IBOutlet weak var logoTopC: NSLayoutConstraint!
    @IBOutlet weak var woman2BottomC: NSLayoutConstraint!
    
    
    
    
    
    var isHandledJazzHands: Bool = NO
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        /** 视图准备 */
        self.viewPrepare()

    }


    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        /** 专门处理手势帧动画 */
        self.jassHandzPrepare()
        
        CoreSVP.showSVPWithType(CoreSVPTypeBottomMsg, msg: "欢迎使用来来，请您轻轻慢慢的向左滑动~", duration: 5, allowEdit: true, beginBlock: nil, completeBlock: nil)
    }
    
    
    /** 视图准备 */
    func viewPrepare(){
        
        //状态色
        enterBtn.backgroundColorForNormal = hexColor("e94e50")
        enterBtn.backgroundColorForHighlighted = hexColor("b12e2e")
        
        //圆角
        enterBtn.radius = 5
    }
    

    
    /** scrollView代理方法区 */
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
        let time = Int(scrollView.contentOffset.x)
        
        self.animate(time)
    }
    
    @IBAction func enterAction(sender: AnyObject) {
        
        self.view.window?.toggleRootVC()
    }
   
    
    
    
}
