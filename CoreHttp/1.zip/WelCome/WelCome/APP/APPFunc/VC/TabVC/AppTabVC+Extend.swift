//
//  AppTabVC+Extend.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension AppTabVC{
    
    /** 组织子控制器 */
    func childVCsHandle(){
        
        self.tabBar.tintColor = AppConst.AppColor
        
        /** 首页 */
        var indexVC = childVCPrepare(IndexVC.self,name:"首页" , icon: "main", hasNib: YES)
        
        /** 收藏 */
        var collectionVC = childVCPrepare(FavoritesVC.self,name:"收藏", icon: "favorites", hasNib: NO)
        
        
        /** 发现 */
        var discoverVC = childVCPrepare(DiscoverVC.self,name:"发现", icon: "find", hasNib: NO)
        
        /** 我的 */
        var mineVC = childVCPrepare(MineVC.self,name:"我的", icon: "mine", hasNib: YES)
        
        self.viewControllers = [indexVC,collectionVC,discoverVC,mineVC]
    }
    
    
    /** 每个控制器定制 */
    func childVCPrepare(Cls: Any.Type,name: String , icon: String, hasNib: Bool) -> AppNavVC {
        
        //类型强转
        let ClassType = Cls as! UIViewController.Type
        
        //创建控制器
        let vc = hasNib ? ClassType.controllerInitWithNib() : ClassType()
        
        var navVC = AppNavVC(rootViewController: vc)
        
        //设置标题
        navVC.tabBarItem.title = name
        
        //设置图标
        navVC.tabBarItem.image = UIImage(named: icon)
        
        return navVC
    }
    
    
    
    
    
    
    
}

