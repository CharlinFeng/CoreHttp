//
//  AppTVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class AppTVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.backgroundColor = hexColor("eeefef")
    }
}

extension AppTVC{
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: YES)
    }
}