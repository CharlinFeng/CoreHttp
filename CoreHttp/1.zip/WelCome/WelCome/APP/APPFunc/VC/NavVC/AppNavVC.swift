//
//  AppNavVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class AppNavVC: BaseNav {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //定制外观
        self.navBarAppearanceWithBgColor(AppConst.AppColor, textColor: UIColor.whiteColor(), titleFontPoint: 22, itemFontPoint: 16)
        
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        
        return UIStatusBarStyle.LightContent
    }

    class func rootVC(vc: UIViewController) ->AppNavVC{
        return AppNavVC(rootViewController: vc)
    }
}
