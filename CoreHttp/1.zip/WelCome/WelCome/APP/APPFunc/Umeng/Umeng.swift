//
//  Umeng.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


/** 友盟的AppKey */
let UmengAppKey = "55b0488f67e58eb756005ec5"

let APPURL = "http://211.149.151.92/lailai/static/homepage.html"


/** 新浪 */

/** 新浪的APPKEY */
let SinaAppKey = "4099294290"

/** 新浪回调页面 */
let SinaRedirectURL = APPURL




/** 微信 */

/** 微信AppID */
let WXAppID = "wx75350cb1b305708e"

/** 微信APPsecret */
let WXAPPsecret = "789e3593d536389226a472597360fc9b"

/** 微信回调页 */
let WXRedirectURL = APPURL





/** QQ */

/** QQAppID */
let QQAppID = "1104789314"

/** QQAPPsecret */
let QQAPPsecret = "qPHijIaKKY6pA4SV"

/** QQ回调页 */
let QQRedirectURL = APPURL


