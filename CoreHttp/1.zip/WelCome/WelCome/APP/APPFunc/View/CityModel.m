//
//  CityModel.m
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "CityModel.h"
#import "NSObject+MJKeyValue.h"

static NSArray *_CityModels;

@implementation CityModel

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"hostID":@"id"};
}

+(NSDictionary *)objectClassInArray{
    return @{@"children": [self class]};
}


+(NSArray *)cityModels{
    
    if (_CityModels == nil) {
        
        NSURL *pathUrl = [[NSBundle mainBundle] URLForResource:@"City" withExtension:@"plist"];
        
        NSLog(@"%@",pathUrl);
        
        NSArray *cityArray = [NSArray arrayWithContentsOfURL:pathUrl];
        
        _CityModels = [self objectArrayWithKeyValuesArray:cityArray]; 
    }
    
    return _CityModels;
}


/** 根据id寻找城市名 */
+(NSString *)cityName:(NSInteger)cityID{
    
    __block NSString *cityName = @"请选择";
    
    [[self cityModels] enumerateObjectsUsingBlock:^(CityModel *cityModel1, NSUInteger idx, BOOL *stop) {
       
        [cityModel1.children enumerateObjectsUsingBlock:^(CityModel *cityModel2, NSUInteger idx, BOOL *stop) {
            
            
            if (cityModel2.hostID == cityID){
                cityName = [NSString stringWithFormat:@"%@-%@",cityModel1.name,cityModel2.name];
            }
            
        }];
        
    }];
    
    return cityName;
}

@end
