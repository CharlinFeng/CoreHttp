//
//  CityModel.h
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CityModel : NSObject

@property (nonatomic,assign) NSInteger hostID,pid;

@property (nonatomic,copy) NSString *name,*spell;

@property (nonatomic,strong) NSArray *children;

+(NSArray *)cityModels;

/** 根据id寻找城市名 */
+(NSString *)cityName:(NSInteger)cityID;

@end
