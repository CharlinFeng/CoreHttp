//
//  CityPickerView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class CityPickerView: UIPickerView,UIPickerViewDataSource,UIPickerViewDelegate {
    
    lazy var dataList: [CityModel] = { return CityModel.cityModels() as! [CityModel] }()

    var selectedRow1: Int = 0
    var selectedRow2: Int = 0
    
    var selectedCityModel: CityModel?{
        
        return dataList[selectedRow1].children[selectedRow2] as? CityModel
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    /** 视图准备 */
    func viewPrepare(){
        self.dataSource = self
        self.delegate = self
        self.backgroundColor = UIColor.whiteColor()
    }
    
    /** pickerView */
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            
            return dataList.count
            
        }else{
    
            return dataList[selectedRow1].children.count
        }
        
    }

    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        
        if component == 0 {
            return dataList[row].name
            
        }else{
            
            return dataList[selectedRow1].children[row].name
        }
    }
    
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if component == 1 {
        
            selectedRow2 = row; return
        }
        
        selectedRow1 = row
        pickerView.reloadComponent(1)
        pickerView.selectRow(0, inComponent: 1, animated: YES)
    }
    
    
    
}
