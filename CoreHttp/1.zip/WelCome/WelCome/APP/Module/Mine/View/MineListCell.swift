//
//  MineListCell.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class MineListCell: BaseTableViewCell {

    @IBOutlet weak var iconImageV: UIImageView!
    
    @IBOutlet weak var mineListLabel: UILabel!
    
    @IBOutlet weak var idcImageV: UIImageView!
    
    @IBOutlet weak var bodyView: UIView!
    
    
    @IBOutlet weak var labelLeftC: NSLayoutConstraint!
    
    
    
    override func awakeFromNib() {
        
        //右边的前头
        idcImageV.image = UIImage(named: "return")?.imageWithGradientTintColor(hexColor("595757")).rotate(CGFloat(M_PI))
        

        
    }
    
    override func dataFill(baseModel: BaseModel!) {
        
        //类型强转
        let listModel = baseModel as! MineListModel
        
        if listModel.iconImageName == nil {
            
            iconImageV.removeFromSuperview()
            labelLeftC.priority = 300
            
        }else{
            //填充数据
            //图片
            iconImageV.image = UIImage(named: listModel.iconImageName)
            
            //添加下划线
            bodyView.addSingleBorder(UIViewBorderDirectBottom, color: hexColor("e6e6e7"), width: 1)
        }
        

        //标题
        mineListLabel.text = listModel.title
    }
    
    
    
}
