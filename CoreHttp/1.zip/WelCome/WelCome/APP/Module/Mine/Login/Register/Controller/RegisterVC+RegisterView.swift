//
//  RegisterVC+RegisterView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit


extension RegisterVC{
    
    

    
    /** 处理顶部的注册视图 */
    func regisgerViewPrepare(){
        
        //模型准备
        let w1 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Mobile(btnTag: btnTag), hasBottomBorder: YES))
        w1.textField.keyboardType = UIKeyboardType.NumberPad
        self.mobileTF = w1.textField
        
        
        
        let w2 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "验证码"), hasBottomBorder: YES))
        w2.textField.keyboardType = UIKeyboardType.NumberPad
        self.verifyTF = w2.textField
        
        let w3 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "密码"), hasBottomBorder: YES))
        self.pwdTF = w3.textField
        
        let w4 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "重复密码"), hasBottomBorder: NO))
        self.rpwdTF = w4.textField
        
        //设置数据
        self.registerView.wrapViews = [w1,w2,w3,w4]
    }
    

        

    
    
    
}

