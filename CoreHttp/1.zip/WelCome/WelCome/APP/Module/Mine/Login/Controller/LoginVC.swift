//
//  LoginVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    
    @IBOutlet weak var registerView: RegisterInputView!
    
    @IBOutlet weak var loginBtn: AppSubmitBtn!
    
    var isDismissType: Bool = false
    
    
    weak var userNameTF: UITextField!
    weak var pwdTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        /** 控制器准备 */
        vcPrepare()
        
        /** 处理注册视图 */
        registerViewHandle()
    }
    
    
    /** 控制器准备 */
    func vcPrepare(){
        
        self.title = "登陆"
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "注册", style: UIBarButtonItemStyle.Plain, target: self, action: "registerAction")
    }
    
    /** 注册 */
    func registerAction(){
        
        let registerVC = RegisterVC.controllerInitWithNib() as! RegisterVC
        
        registerVC.type = RegisterVC.VCType.Register
        self.navigationController?.pushViewController(registerVC, animated: YES)
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        self.view.endEditing(YES)
    }
    
    
    /** 忘记密码 */
    @IBAction func forgetPwdSction(sender: UIButton) {
        
        let registerVC = RegisterVC.controllerInitWithNib() as! RegisterVC
        
        registerVC.type = RegisterVC.VCType.ForgetPwd
        self.navigationController?.pushViewController(registerVC, animated: YES)
    }
    
    @IBAction func loginAction(sender: AnyObject) {
        
        let errorMsg = UITextField.checkWithTFCheckModels { () -> [UITextField.TFCheckModel] in
            
            let m1 = UITextField.TFCheckModel(textField: self.userNameTF, desc: "用户名")
            let m2 = UITextField.TFCheckModel(textField: self.pwdTF, desc: "密码")
            
            return [m1,m2]
        }
        
        if errorMsg.isNotEmpty {
            
            
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: errorMsg, duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            
            return
        }
        
        let url = URL_LOGIN.completeURL
        let pwd = (pwdTF.text as NSString).md5
        let params = ["account": userNameTF.text,"pwd":pwd]
        APPHttp.postUrl(url, params: params, target: self.view, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            
            let userModel = UserModel(keyValues: data)
            
            //保存
            UserModel.saveSingleModel(userModel, forKey: nil)
            
            let mineVC = self.navigationController?.viewControllers.first as? MineVC
            
            //刷新用户数据
            mineVC?.reloadUserModelData()
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "登陆成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: { () -> Void in
                
                if self.isDismissType {
                    self.dismissViewControllerAnimated(true, completion: nil)
                }else{
                    self.navigationController?.popViewControllerAnimated(YES)
                }
                
                NSNotificationCenter.defaultCenter().postNotificationName(LoginSuccessNoti, object: nil)
                
            })
            
            
        }, errorBlock: nil)
        
    }
    
    
    
    
}
