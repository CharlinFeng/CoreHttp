//
//  RegisterVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {
    
    @IBOutlet weak var registerView: RegisterInputView!
    
    var mobileTF,verifyTF,pwdTF,rpwdTF: UITextField!
    
    let btnTag = 1
    
    var vid: Int!
    
    var type: VCType!
    
    @IBOutlet weak var btn: AppSubmitBtn!
    
    @IBOutlet weak var protocolBtn: UIButton!
    
    
    override func viewDidLoad() {
        
        /** 处理顶部的注册视图 */
        regisgerViewPrepare()
        
        /** 请求入口 */
        requestBegin()
        
        
        self.title = type == VCType.Register ? "注册" : "忘记密码"
        
        btn.setTitle(type == VCType.Register ? "注册" : "重置密码", forState: UIControlState.Normal)
        
        protocolBtn.hidden = type != VCType.Register
    }
    

    
    /** 用户协议 */
    @IBAction func protocolAction(sender: AnyObject) {
        self.view.endEditing(YES)
        
        let webVC = SVWebViewController(address: URL_USER_PROTOCOL)
        
        webVC.addDismissBarButton()
        
        let navVC = AppNavVC.rootVC(webVC)
        
        self.presentViewController(navVC, animated: true, completion: nil)
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        self.view.endEditing(YES)
    }
    
    
}
