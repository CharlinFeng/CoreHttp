//
//  RegisterVC+Request.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/22.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


/** 请求 */
extension RegisterVC{
    
    
    /** 电话号码 */
    var mobileCode: String{
        return self.mobileTF.text
    }
    
    /** 验证码 */
    var veryfiCode: String{
        return self.verifyTF.text
    }
    
    /** 密码 */
    var pwdCode: String{
        return self.pwdTF.text
    }
    
    /** 重复密码 */
    var rpwdCode: String{
        return self.rpwdTF.text
    }
    
    
    /** 请求入口 */
    func requestBegin(){
        
        
        //注册通知
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "getVerifyBtnClick:", name:RegisterBtnClickNoti , object: nil)
    }
    
    
    /** 点击了获取验证码 */
    func getVerifyBtnClick(noti: NSNotification){
        
        //取出btn
        let btn = noti.object as! CoreCountBtn
        
        if btn.tag != btnTag {return}
        
        var errorMsg = ""
        
        if !((mobileCode as NSString).isMobileNO) {errorMsg = "手机号格式不正确"}
        if mobileCode.isEmpty {errorMsg = "请输入手机号"}
        
        if errorMsg.isNotEmpty {CoreToast.showMsgType(CoreToastMsgTypeError, msg: "错误", subMsg: errorMsg, timeInterval: 3.0, trigger: btn, apperanceBlock: nil, completionBlock: nil);return}
        
        btn.status = CoreCountBtnStatusCounting
        
        let url = URL_GET_CODE.completeURL
        
        let params = ["phone": mobileCode,"type":self.type.rawValue]
        
        
//        CoreSVP.showSVPWithType(CoreSVPTypeLoadingInterface, msg: "处理中", duration: 3.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
        
        
        //正式请求
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in

            let dict: [NSObject: AnyObject] = objectConvertToDictionay(data)!
            
            self.vid = dict["vid"] as! Int
            
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "短信下发成功", duration: 3.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            
        }, errorBlock: nil)
        
    }
    
    /** 注册 */
    @IBAction func registerAction(sender: AppSubmitBtn) {
        self.view.endEditing(YES)
        
        
        if self.vid == nil {//说明用户没有点击获取验证码按钮
        
            CoreToast.showMsgType(CoreToastMsgTypeError, msg: "错误", subMsg: "请先获取验证码", timeInterval: 3.0, trigger: sender, apperanceBlock: nil, completionBlock: nil);return
        }
        
        
        var errorMsg = UITextField.checkWithTFCheckModels { () -> [UITextField.TFCheckModel] in
            
            let m1 = UITextField.TFCheckModel(textField: self.mobileTF, desc: "手机号")
            let m2 = UITextField.TFCheckModel(textField: self.verifyTF, desc: "验证码")
            let m3 = UITextField.TFCheckModel(textField: self.pwdTF, desc: "密码")
            let m4 = UITextField.TFCheckModel(textField: self.rpwdTF, desc: "确认密码")
            
            return [m1,m2,m3,m4]
        }
        
        
        if pwdCode != rpwdCode {errorMsg = "再次密码不一致"}
        
        
        if errorMsg.isNotEmpty{CoreToast.showMsgType(CoreToastMsgTypeError, msg: "错误", subMsg: errorMsg, timeInterval: 3.0, trigger: sender, apperanceBlock: nil, completionBlock: nil);return}
        
        
        //注册
        let url = URL_REGISTER.completeURL
        
        let params = ["phone": mobileCode, "verify": veryfiCode, "pwd": (pwdCode as NSString).md5, "vid": self.vid,"type":self.type.rawValue]
        
        //正式请求
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            var title = "密码重置成功"
            
            if RegisterVC.VCType.Register == self.type { //注册
                
                //解析模型
                let userModel: UserModel = UserModel(keyValues: data)
                
                //保存
                UserModel.saveSingleModel(userModel, forKey: nil)
                
                title = "注册成功"
                
            }
            
            CoreAleetViewManagerVC.show(AlertSuccess, style: AlertStyleDrop, title:title , desc: "请您登陆", destructiveTitle: "好的", cancelTitle: nil, clickBlock: { (index) -> Void in
                
                self.navigationController?.popViewControllerAnimated(YES)
                
            })
            
        }, errorBlock: nil)
        
        
        
    }
}