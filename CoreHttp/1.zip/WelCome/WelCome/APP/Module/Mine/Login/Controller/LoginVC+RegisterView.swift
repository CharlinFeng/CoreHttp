//
//  LoginVC+RegisterView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



/** 处理注册视图 */
extension LoginVC{
    
    
    /** 处理注册视图 */
    func registerViewHandle(){
        
        //模型准备
        let w1 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Image(imageName: "login_uesr", ph: "手机号/来来号"), hasBottomBorder: YES))
        userNameTF = w1.textField
        userNameTF.keyboardType = UIKeyboardType.NumberPad
        
        let w2 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Image(imageName: "login_password", ph: "密码"), hasBottomBorder: NO))
        w2.textField.secureTextEntry = YES
        pwdTF = w2.textField
        
        //设置数据
        self.registerView.wrapViews = [w1,w2]
        
        /** 点击了注册 */
        loginBtn.addTarget(self, action: "registerAction:", forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    
    /** 点击了注册 */
    func registerAction(btn: AppSubmitBtn){
        self.view.endEditing(YES)
        
    }
    
    
}








