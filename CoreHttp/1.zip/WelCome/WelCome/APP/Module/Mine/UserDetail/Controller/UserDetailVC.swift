//
//  UserDetailVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class UserDetailVC: AppTVC {

    var userModel: UserModel = UserModel.readSingleModelForKey(nil)
    
    var isModifying: Bool = false

    var modifiedNick: String!{didSet{updateNick()}}
    
    var headView: UserDetailCell!
    
    weak var mineVC :MineVC!
    
    /** 用户是否动手处理过自己的资料？ */
    var isHandleYourData: Bool = NO
    
    lazy var pickerView: CityPickerView = CityPickerView(frame: CGRectMake(0, 0, Screen.width, 216))
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.title = "个人信息"
        
        /** dataPrepare */
        dataPrepare()
    }


}


