//
//  UserDetailCell.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class UserDetailCell: BaseTableViewCell {

    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var iconView: IconView!
    
    @IBOutlet weak var leftLabel: UILabel!
 
    @IBOutlet weak var leftDetailLabel: UILabel!
    
    @IBOutlet weak var thirdView: ThirdView!
    
    @IBOutlet weak var modifyLabel: UILabel!

    @IBOutlet weak var idv: UIImageView!
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var actionBtn: UIButton!
    
    var btnClickClosure: (() -> Void)!
    

    
}


extension UserDetailCell{
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        idv.image = UIImage(named: "return")?.imageWithGradientTintColor(hexColor("595757")).rotate(CGFloat(M_PI))
    }
    
    @IBAction func btnClick(sender: AnyObject) {
        
        if btnClickClosure != nil {btnClickClosure()}
    }
    
    override func dataFill(baseModel: BaseModel!) {
        
        //数据强转
        let detailCellModel = baseModel as! UserDetailCellModel
        
        if UserDetailCellModel.CellType.HeaderView == detailCellModel.cellType {//HeaderView
            
            //隐藏
            leftLabel.hidden = YES
            leftDetailLabel.hidden = YES
            thirdView.hidden = YES
            
        }else if UserDetailCellModel.CellType.DetailTextCell == detailCellModel.cellType {//detailTextView
            
            //隐藏
            actionBtn.hidden = YES
            iconView.hidden = YES
            modifyLabel.hidden = YES
            thirdView.hidden = YES
            
            //设置
            leftLabel.text = detailCellModel.title
            leftDetailLabel.text = detailCellModel.desc

        }else{
            
            //隐藏
            actionBtn.hidden = YES
            iconView.hidden = YES
            leftDetailLabel.hidden = YES
            modifyLabel.hidden = YES
            
            //设置
            leftLabel.text = detailCellModel.title

        }
        
        
        
    }
    
}