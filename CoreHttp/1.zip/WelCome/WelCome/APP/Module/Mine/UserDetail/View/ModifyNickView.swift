//
//  ModifyNickView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ModifyNickView: UIView {

    @IBOutlet weak var textField: BaseTF!
    
    var saveClosure:((nick: String!)->Void)!
    
    @IBAction func saveAction(sender: AnyObject) {
        
        if saveClosure != nil {saveClosure!(nick: textField.text)}
        
    }
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        textField.radius = 4
        textField.leftPadding = 8
    }
    
    

}
