//
//  UserDetailVC+Data.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension UserDetailVC{
    
    var dataList: [[UserDetailCellModel]]{
        
        println("dataList====\(userModel.name)")
        
        let nick = userModel.name.length == 0 ? "请输入" : userModel.name
        
        let m1 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "昵称", desc: nick)
        m1.actionClosure = {
            
            let modifyNickVC = ModifyNickVC()
            modifyNickVC.detailVC = self
            let navVC = AppNavVC(rootViewController: modifyNickVC)
            
            self.presentViewController(navVC, animated: YES, completion: nil)
            
        }
        
        
        let m2 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "手机", desc: userModel.phone)
        m2.actionClosure = {
            
            let modifyMobileVC = ModifyMobileVC.controllerInitWithNib()
            
            self.navigationController?.pushViewController(modifyMobileVC, animated: YES)
        }
        
        
        let m3 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "密码", desc: "修改")
        m3.actionClosure = {
            
            let modifyPwdVC = ModifyPwdVC.controllerInitWithNib()
            
            self.navigationController?.pushViewController(modifyPwdVC, animated: YES)
        }
        
        
        
        let m4 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailThirdCell, title: "第三方登陆账号", desc: "空")
        
        let vipDesc = userModel.vip == 0 ? "点此升级" : "VIP"
        let m5 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "会员身份", desc: vipDesc)
        
        m5.actionClosure = { [unowned self] in
        
            if self.userModel.vip == 0 {
            
                CoreAleetViewManagerVC.show(AlertInfo, style: AlertStyleDrop, title: "免费升级VIP", desc: "推广期免费升级", destructiveTitle: "升级", cancelTitle: "不升", clickBlock: { (index) -> Void in
                    
                    if index == 1 {return}
                    
                    //升级
                    self.userModel.vip = 1
                    
                    self.tableView.reloadData()
                    
                    /** 更新vip信息 */
                    self.updateVipData()
                    self.isHandleYourData = YES
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,Int64(1 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), { () -> Void in
                        
                        CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "您已升级为VIP啦", duration: 2.0, allowEdit: YES, beginBlock: nil, completeBlock: nil)
                    })
                })
            
            
            }else{
                
                CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "已经是VIP", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            }
        
        
        }
        
        let sex = userModel.sexStr
        let m6 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "性别", desc: sex)
        m6.actionClosure = { [unowned self] in
        
            CoreAleetViewManagerVC.showWithAleetViewType(CoreAleetViewTypeUIActionSheet, inController: self, title: "请选择性别", message: "请选择性别", cancelButtonTitle: "取消", destructiveButtonTitle: nil, otherButtonTitles: ["男","女"], clickedButtonBlock: { (index) -> Void in
                
                if index == 1 {return}
                
                self.userModel.sex = index == 0 ? 1 : 2
                self.isHandleYourData = YES
                self.tableView.reloadData()
            })
        }
        
        let city = CityModel.cityName(userModel.addressID)
        
        let m7 = UserDetailCellModel(cellType: UserDetailCellModel.CellType.DetailTextCell, title: "常居地", desc: city)
        
        
        
        
        return [
            
            [m1,m2,m3],
            
            [m5],
            
            [m6,m7]
            
        ]
        
    }
    
    /** 更新了昵称 */
    func updateNick(){
        
        userModel.name = self.modifiedNick
        self.isHandleYourData = YES
        self.tableView.reloadData()
    }
    
    
    /** dataPrepare */
    func dataPrepare(){
        
        self.tableView.separatorInset = UIEdgeInsetsMake(0, 15, 0, 0)
        
        //设置headerView
        let headerView = UserDetailCell.viewFromXIB()
        headerView.frame = CGRectMake(0, 0, 0, 75)
        let m = UserDetailCellModel(cellType: UserDetailCellModel.CellType.HeaderView, title: nil, desc: nil)
        
        self.headView = headerView
        headerView.baseModel = m
        
        
        
        
        
        headerView.btnClickClosure = { [unowned self] in
        
            CoreAleetViewManagerVC.showWithAleetViewType(CoreAleetViewTypeUIActionSheet, inController: self, title: "请选择", message: nil, cancelButtonTitle: "取消", destructiveButtonTitle: nil, otherButtonTitles: ["拍摄","相册"], clickedButtonBlock: { (index) -> Void in
                
                if index == 1 {return}
                
                //创建
                let managerVC = CorePhotoPickerVCManager.sharedCorePhotoPickerVCManager()
                
                //设置类型
                managerVC.pickerVCManagerType = index == 2 ? CorePhotoPickerVCMangerTypeSinglePhoto : CorePhotoPickerVCMangerTypeCamera
                

                
                //选取结束
                managerVC.finishPickingMedia = {[unowned self] (medias) -> Void in
                
                    let photo: CorePhoto = medias.first as! CorePhoto
                    
                    self.userModel.headImage = photo.editedImage
                    self.isHandleYourData = YES
                    /** 更新头像 */
                    self.updateHeadImageData()
                    
                }

                let pickerVC = managerVC.imagePickerController
                
                //错误处理
                if managerVC.unavailableType.value != CorePhotoPickerUnavailableTypeNone.value || pickerVC == nil{
                    
                    CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "设备不支持", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
                    
                    return
                }
                
                self.presentViewController(pickerVC, animated: YES, completion: nil)
            
            })
            
        }
        

        /** 更新头像 */
        updateHeadImageData()
        
        /** 更新vip信息 */
        updateVipData()
        
        
        self.tableView.tableHeaderView = headerView
        
        self.tableView.contentInset = UIEdgeInsetsMake(10, 0, 10, 0)
        self.tableView.tableFooterView = UIView()
        self.tableView.separatorInset = UIEdgeInsetsMake(0, 15, 0, 15)
        self.tableView.separatorColor = hexColor("e0e1e1")

        
        let footerView = UserDetailFooterView()
        footerView.frame = CGRectMake(0, 0, 0, 85)
        self.tableView.tableFooterView = footerView
        footerView.btnClickClosure = {[unowned self] in
        
            if !self.isHandleYourData {
            
                CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "未做任何修改", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
                return
            }
            
            //提交修改
            let url = URL_MODIFY_USER_DATA.completeURL
            
            let params = ["token": self.userModel.token,"vip":self.userModel.vip,"sex":self.userModel.sex,"cityID":self.userModel.addressID]
            
            let image = self.userModel.headImage
        
            let files: [UploadFile]? = image == nil ? nil : [UploadFile(key: "photo[]", data: UIImageJPEGRepresentation(self.userModel.headImage, 0.6), name: "icon.jpg")]
            
            CoreSVP.showSVPWithType(CoreSVPTypeLoadingInterface, msg: "处理中", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            CoreHttp.uploadUrl(url, params: params, files: files, success: {[unowned self] (data) -> Void in
                
                let dict: NSDictionary = data as! NSDictionary
            
                let code = (dict["data"] as! NSDictionary)["dataStatus"] as! String
                
                if code != "200" {
                    
                    self.showError()
                    return
                }
                
                let dictData = (dict["data"] as! NSDictionary)["dataData"] as! NSDictionary
                
                let userModelNew = UserModel(keyValues: dictData)
            
                
                UserModel.saveSingleModel(userModelNew, forKey: nil)
                
                self.mineVC.reloadUserModelData()
                
                CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "修改成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: { () -> Void in
                    
                    self.navigationController?.popViewControllerAnimated(YES)
                })
            
                
                
                
                
                }, errorBlock: {[unowned self] (error) in
                    self.showError()
                })
            
            
            
            
        }
        
        leftBtn()
        
//        rightBtn()
        
    }
    
    /** 提示错误 */
    func showError(){
        CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "修改失败", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
    }
    
    
    
    
    /** 更新头像 */
    func updateHeadImageData(){
        //设置头像
        
        if userModel.headImage == nil {
            
            headView.imageView?.imageWithUrlStr(userModel.photo.resourceURL, phImage: nil)
            
        }else{
            
            headView.iconView.imageView.image = userModel.headImage
        }
    }
    
    /** 更新vip信息 */
    func updateVipData(){
        
        headView.iconView.isVip = userModel.vip == 1
    }
    
    /** 修改 */
    func modifyAction(){
        isModifying = !isModifying
        leftBtn()
        rightBtn()
    }
    
    
    
    /** 左边 */
    func leftBtn(){
        
        let leftBtn = !isModifying ? UIBarButtonItem(target: self, action: Selector("popNav"), image: "return", highImage: "return") : UIBarButtonItem(title: "取消", style: UIBarButtonItemStyle.Plain, target: self, action: "cancelAction")

        self.navigationItem.leftBarButtonItem = leftBtn
    }
  
    /** 右边 */
    func rightBtn(){
        let title = isModifying ? "保存" : "修改"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: title, style: UIBarButtonItemStyle.Plain, target: self, action: "modifyAction")
    }
    
    
    /** pop */
    func popNav(){
        
        if isHandleYourData {
            
            CoreAleetViewManagerVC.show(AlertInfo, style: AlertStyleDrop, title: "修改资料未提交", desc: "是否真的不保存？", destructiveTitle: "我点错了", cancelTitle: "继续退出", clickBlock: { (index) -> Void in
                
                if index == 0 {return}
                
                self.navigationController?.popViewControllerAnimated(YES)
            })
            
        }else{
            self.navigationController?.popViewControllerAnimated(YES)
        }
        
    }
    
    /** 取消 */
    func cancelAction(){
        
        CoreAleetViewManagerVC.show(AlertInfo, style: AlertStyleDrop, title: "注意", desc: "确定放弃修改？", destructiveTitle: "不", cancelTitle: "放弃") {[unowned self] (index) -> Void in
            
            if index == 1 {//放弃
                self.popNav()
            }
        }
    }
    
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return dataList.count
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList[section].count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let detailCell = UserDetailCell(fromTableView: tableView) as UserDetailCell
        
        //传递数据
        detailCell.baseModel = dataList[indexPath.section][indexPath.row]
        
        
        println(dataList[indexPath.section][indexPath.row].desc)
        return detailCell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: YES)
        dataList[indexPath.section][indexPath.row].actionClosure?()
        
        if indexPath.section == 2 && indexPath.row == 1 {cityHandle(indexPath)}
    }
    
    /** 处理城市 */
    func cityHandle(indexPath: NSIndexPath){
        
        let cell = self.tableView.cellForRowAtIndexPath(indexPath) as! UserDetailCell
        cell.textField.inputView = pickerView
        let keyboardBarView = KeyBoardBarView.viewFromXIB()
        keyboardBarView.clickItemClosure = {[unowned self,cell] (btn,index) -> Void in
            
            if index == 1 {
                
                //取出城市ID
                if let cityModel = self.pickerView.selectedCityModel {
                    
                    self.userModel.addressID = cityModel.hostID
                    
                    cell.textField.resignFirstResponder()
                    self.isHandleYourData = YES
                    self.tableView.reloadData()
                }
                
            }
            
        }
        cell.textField.inputAccessoryView = keyboardBarView
        cell.textField.becomeFirstResponder()
    }

    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 46
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
}