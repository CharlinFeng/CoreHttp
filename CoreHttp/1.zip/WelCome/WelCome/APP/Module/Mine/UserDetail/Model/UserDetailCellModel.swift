//
//  UserDetailCellModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation
import UIKit


extension UserDetailCellModel{
    
    enum CellType{
        
        case HeaderView
        case DetailTextCell
        case DetailThirdCell
    }
}



class UserDetailCellModel: BaseModel {
    
    let cellType: CellType!
    
    let title: String!
    
    var desc: String!
    
    var actionClosure: (()->Void)!
    
    var inputView: UIView!
    
    init(cellType: CellType, title: String!, desc: String!){
        
        self.cellType = cellType
        self.title = title
        self.desc = desc
    }
}










