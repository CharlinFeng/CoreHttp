//
//  ModifyNickVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ModifyNickVC: UIViewController {
    
    let nickView = ModifyNickView.viewFromXIB()
    weak var detailVC: UserDetailVC!
    
    
    override func loadView() {
        
        self.view = nickView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.addDismissBarButton()
        
        self.title = "昵称"
        
        nickView.saveClosure = { [unowned self] (nick: String!) ->Void in
            
            if nick == nil || nick.length == 0 {
            
                CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请填写昵称", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
                return
            }
            
            if self.detailVC == nil {return}
            
            let um = UserModel.readSingleModelForKey(nil)
            
            self.detailVC.modifiedNick = nick
            
            let url = URL_MODIFY_NICK.completeURL
            
            let params = ["token":um.token, "newName": nick]
            

            
            APPHttp.postUrl(url, params: params, target: self.view, type: APPHttpTypeSVP, success: { (data) -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    
                    self.dismissViewControllerAnimated(YES, completion:nil)
                })
                
            }, errorBlock: nil)
            
            
        }
    }
    
}
