//
//  UserDetailFooterView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class UserDetailFooterView: UIView {
    
    var btnClickClosure: (()->Void)!

    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    /** 视图准备 */
    func viewPrepare(){
        
        let btn = AppSubmitBtn()
        
        btn.setTitle("修改资料", forState: UIControlState.Normal)
        
        self.addSubview(btn)
        
        //添加约束
        btn.make_4Insets(UIEdgeInsetsMake(22, 18, 22, 18))
        
        btn.addTarget(self, action: "btnClick", forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    /** 事件 */
    func btnClick(){
        
        if btnClickClosure != nil { btnClickClosure()}
    }
    

}
