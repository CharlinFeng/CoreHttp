//
//  MoreVC+TableView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension MoreVC: UITableViewDataSource,UITableViewDelegate{
    
    
    var dataList: [MineListModel] {
        
        let m1 = MineListModel(iconImageName: nil, title: "查看用户协议")
        
        return [m1]
    }
    
    /** tableView准备 */
    func tableViewPrepare(){
        
        
        self.tableViewHC.constant = CGFloat(45 * dataList.count)
        
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.None
    }
    
    

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = MineListCell(fromTableView: tableView)
        
        cell.baseModel = dataList[indexPath.row]
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: YES)
        
        let webVC = SVWebViewController(address: URL_USER_PROTOCOL)
        
        self.navigationController?.pushViewController(webVC, animated: YES)
    }
    
    
    
    
    
}