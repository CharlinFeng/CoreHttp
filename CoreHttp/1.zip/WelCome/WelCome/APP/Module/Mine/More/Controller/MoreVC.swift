
//
//  MoreVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit


class MoreVC: AppVC {
    
    @IBOutlet weak var tableViewHC: NSLayoutConstraint!
    
    @IBOutlet weak var versionLabel: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var logoutBtn: AppSubmitBtn!
    
    
    lazy var userModel: UserModel! = { UserModel.readSingleModelForKey(nil)}()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "更多设置"
        
        /** tableView准备 */
        tableViewPrepare()
        
        versionLabel.text = String(format: "当前版本号：V %.1f", Float(CoreArchive.currentVersion().toInt()!))
        
        logoutBtn.hidden = userModel == nil
    }
    
    @IBAction func loginOutAction(sender: AnyObject) {
        
        let url = URL_LOGOUT.completeURL
        
        let params = ["token": userModel.token,"phone": userModel.phone]
        
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            //清空用户模型
            UserModel.saveSingleModel(nil, forKey: nil)
            
            let mineVC = self.navigationController?.childViewControllers.first as! MineVC
            
            mineVC.reloadUserModelData()
            
            NSNotificationCenter.defaultCenter().postNotificationName(LogoutSuccessNoti, object: nil)
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "退出成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: { () -> Void in
                
                
                
                self.navigationController?.popViewControllerAnimated(YES)
                
            })
            
        }, errorBlock: nil)
    }
    

}
