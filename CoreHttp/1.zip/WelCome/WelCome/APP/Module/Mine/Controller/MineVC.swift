//
//  MineVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class MineVC: UIViewController {
    
    @IBOutlet weak var idcImageV: UIImageView!
    
    @IBOutlet weak var logoutHC: NSLayoutConstraint!
    
    @IBOutlet weak var loginHC: NSLayoutConstraint!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBOutlet weak var userMobileLabel: UILabel!
    
    @IBOutlet weak var lailaiIDLabel: UILabel!
    
    @IBOutlet weak var currentBtn: UIButton!
    
    @IBOutlet weak var historyBtn: UIButton!
    
    @IBOutlet weak var iconView: IconView!
    
    
    
    var userModel: UserModel! {
        
        println("计算")
        return UserModel.readSingleModelForKey(nil)
    }
    
    
    
    private var hasUserModel: Bool{
        
        //读取用户模型
        return UserModel.readSingleModelForKey(nil) != nil
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /** 控制器处理 */
        self.vcPrepare()
        
        /** 处理我的菜单列表 */
        self.mineListPrepare()
        
        /** 刷新用户数据 */
        reloadUserModelData()
    }
    
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)

        let url = URL_COUNT_ORDER.completeURL
        
        let userModel = UserModel.readSingleModelForKey(nil)
        
        if(userModel != nil){
            iconView.imageView.imageWithUrlStr(userModel.photo.resourceURL, phImage: nil)
            iconView.isVip = userModel.vip == 1
        }
        
        
        if userModel == nil {
            
            self.currentBtn.setTitle("当前订单      0", forState: UIControlState.Normal)
            self.historyBtn.setTitle("历史订单      0", forState: UIControlState.Normal)
            
            return}
        
        let params = ["token": userModel.token]
        
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeNone, success: { (data) -> Void in
            
            let dict = data as! [String: String]
            
            let current = dict["nowOrder"]!
            
            let history = dict["historyOrder"]!
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.currentBtn.setTitle("当前订单      \(current)", forState: UIControlState.Normal)
                self.historyBtn.setTitle("历史订单      \(history)", forState: UIControlState.Normal)
            })
            
        }, errorBlock: nil)
    }
    
    
    /** 控制器处理 */
    func vcPrepare(){
        
        self.title = "我的"
        
        //禁止自动延展
        self.edgesForExtendedLayout = UIRectEdge.None
        
        idcImageV.image = UIImage(named: "return")?.imageWithGradientTintColor(hexColor("595757")).rotate(CGFloat(M_PI))

        //登陆按钮圆角处理
        loginBtn.radius = 4
    }
    
    
    /** 刷新用户数据 */
    func reloadUserModelData(){
        
        dispatch_async(dispatch_get_main_queue(), {[unowned self] () -> Void in
            
            //如果有用户模型
            var hasUserModel = self.hasUserModel
            
            //        hasUserModel = NO
            
            if hasUserModel { //有用户模型
                
                self.logoutHC.constant = 0
                self.loginHC.constant = 83
                
                let userModel = UserModel.readSingleModelForKey(nil)
                
                self.userMobileLabel.text = userModel.phone
                self.lailaiIDLabel.text = "来来号："+userModel.lailai_id
                
            }else{//没有用户模型
                
                self.logoutHC.constant = 83
                self.loginHC.constant = 0
            }
        })
    }
    
    
    
    @IBAction func loginAction(sender: AnyObject) {
        
        let loginVC = LoginVC.controllerInitWithNib()
        
        self.navigationController?.pushViewController(loginVC, animated: YES)
    }
    
    @IBAction func showDetail(sender: AnyObject) {
        
        let detailVC = UserDetailVC()
        detailVC.mineVC = self
        self.navigationController?.pushViewController(detailVC, animated: YES)
    }
    
    
    @IBAction func toOrderListVC(sender: UIButton) {
        
        
        let userModel = UserModel.readSingleModelForKey(nil)
    
        if userModel == nil {
        
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "您未登陆", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
        
            return
        }
        
        let orderLTVC = OrderLTVC()
        orderLTVC.orderType = sender.tag
        self.navigationController?.pushViewController(orderLTVC, animated: true)
        
        
    }
    

    
    
}
