//
//  MineVC+MeauList.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/20.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation
import UIKit

/** 菜单处理 */
extension MineVC: UITableViewDataSource,UITableViewDelegate{
    
    var dataList: [MineListModel] {
        
        //准备数据
        let m1 = MineListModel(iconImageName: "mineVip", title: "免费升级VIP")
        let m2 = MineListModel(iconImageName: "settingMessage", title: "给来来留言")
        let m3 = MineListModel(iconImageName: "share", title: "分享给朋友")
        let m4 = MineListModel(iconImageName: "suggestion", title: "意见反馈")
        let m5 = MineListModel(iconImageName: "more", title: "更多设置")
        
        
        /** 升级vip */
        m1.actionClosure = {
            
            if self.userModel == nil {
                
                CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "您未登陆", duration: 2.0, allowEdit: true, beginBlock: nil, completeBlock: nil)
                
                
                return}
            
            let canNotUpgrade = self.userModel == nil || self.userModel.vip == 1
            
            println("\(self.userModel),\(self.userModel.vip)")
            
            
            if canNotUpgrade {
                
                let errorMsg = self.userModel == nil ? "您还没登陆" : "您已经是VIP啦"
                
                CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg:errorMsg , duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
                
            }else{ //还不是vip
                
                CoreAleetViewManagerVC.show(AlertInfo, style: AlertStyleDrop, title: "免费升级VIP", desc: "推广期免费升级", destructiveTitle: "升级", cancelTitle: "不升", clickBlock: {[unowned self] (index) -> Void in
                    
                    if index == 1 {return}
                    
                    let url = URL_UPGRADE_VIP.completeURL
                    
                    let params = ["token": self.userModel.token]
                    
                    APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: {[unowned self] (data) -> Void in
                        
                        //保存
                        let userModel = self.userModel
                        
                        userModel.vip = 1
                        
                        UserModel.saveSingleModel(userModel, forKey: nil)
                        
                        self.reloadUserModelData()
                        
                        CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "升级VIP成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
                        
                    }, errorBlock: nil)
                    
                    
                    
                })
            }
            
        }
        
        
        
        let feedbackClosure = {[unowned self] (vcType: FeedBackVC.VCType) -> Void in
            
            let feedbackVC = FeedBackVC()
            feedbackVC.type = vcType
            
            self.navigationController?.pushViewController(feedbackVC, animated: YES)
        }
        
    
        //设置closure
        m2.actionClosure = {
            
            let feedbackVC = FeedBackVC.controllerInitWithNib() as! FeedBackVC
            feedbackVC.type = FeedBackVC.VCType.Message
            
            self.navigationController?.pushViewController(feedbackVC, animated: YES)
        }
        
        /** 分享 */
        m3.actionClosure = {
            
            
            CoreUmengShare.show(self, text: "来来APP，世界旅游找导游、翻译、公关太方便啦！", image: UIImage(named: "setup_icon"))
        }
        
        m4.actionClosure = {
            
            let feedbackVC = FeedBackVC.controllerInitWithNib() as! FeedBackVC
            feedbackVC.type = FeedBackVC.VCType.FeedBack
            
            self.navigationController?.pushViewController(feedbackVC, animated: YES)
        }
        
        
        
        m5.actionClosure = {
        
            let moreVC = MoreVC.controllerInitWithNib()
        
            self.navigationController?.pushViewController(moreVC, animated: YES)
        }
        
        
        return [m1,m2,m3,m4,m5]
    }
    
    
    /** 处理我的菜单列表 */
    func mineListPrepare(){
        
        //不显示下划线
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = MineListCell(fromTableView: tableView) as MineListCell
        
        //传递数据
        cell.baseModel = dataList[indexPath.row]
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 46
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: YES)
        
        //取出模型
        let model = dataList[indexPath.row]
        
        model.actionClosure?()
    }
    

    
}