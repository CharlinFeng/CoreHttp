//
//  OrderLTVC.m
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "OrderLTVC.h"
#import "OrderLModel.h"
#import "OrderLCell.h"
#import "WelCome-Swift.h"


@interface OrderLTVC ()





@end

@implementation OrderLTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = self.orderType == 1 ? @"历史订单" : @"我的订单";
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = hexColor(eeefef);
    self.view.backgroundColor = hexColor(eeefef);
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    OrderLModel *orderModle = self.dataList[indexPath.item];
    
    OrderDetail *orderDetailVC = [[OrderDetail alloc] initWithNibName:@"OrderDetail" bundle:nil];
    orderDetailVC.orderModel = orderModle;
    
    [self.navigationController pushViewController:orderDetailVC animated:YES];
}




/** 协议方法区 */


/** 刷新方式 */
-(ListVCRefreshAddType)listVC_RefreshType{
    return ListVCRefreshAddTypeBoth;
}


/** 模型类 */
-(Class)listVC_Model_Class{
    return [OrderLModel class];
}


/** 视图类 */
-(Class)listVC_View_Cell_Class{
    return [OrderLCell class];
}

-(NSDictionary *)listVC_Request_Params{
    
    UserModel *userModel = [UserModel readSingleModelForKey:nil];
    
    return @{@"token":userModel.token,@"type":@(self.orderType),@"system":@"ios"};
}


/** 是否移除回到顶部按钮 */
-(BOOL)listVC_Remove_Back2Top_Button{
    return NO;
}


/** tableViewController */
/** cell的行高：tableViewController专用 */
-(CGFloat)listVC_CellH4IndexPath:(NSIndexPath *)indexPath{
    return 135 + 10;
}

/** 无本地FMDB缓存的情况下，需要在ViewDidAppear中定期自动触发顶部刷新事件 */
-(NSString *)listVC_Update_Delay_Key{
    return [NSString stringWithFormat:@"%@%@",NSStringFromClass(self.class),@(self.orderType)];
}


/** 无缓存定期更新周期 */
-(NSTimeInterval)listVC_Update_Delay_Time{
    return 1;
}

/** 是否关闭返回顶部功能 */
-(BOOL)removeBack2TopBtn{
    return NO;
}



@end
