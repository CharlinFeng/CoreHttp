//
//  OrderLModel.h
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"

@interface OrderLModel : BaseModel

@property (nonatomic,copy) NSString *stime,*etime,*message,*contactPhone,*service,*address,*time,*order_no,*trueName,*staffPhoto;

@property (nonatomic,assign) NSInteger type,uid,sid,del,finish_time,staffVip,status;




@end
