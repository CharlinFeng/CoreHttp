//
//  OrderBtn.m
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "OrderBtn.h"
#import "UIView+Extend.h"
#import "WelCome-Swift.h"

@implementation OrderBtn



-(void)setType:(NSInteger)type{
    
    _type = type;
    
    NSArray *titles = @[@"待处理",@"已经完成",@"已取消"];
    
    if (type == 0) {
        
        self.backgroundColorForNormal = [AppConst AppColor];
        self.backgroundColorForHighlighted = hexColor(ba3234);

    }else{ //历史
        self.userInteractionEnabled = YES;
        self.backgroundColorForNormal = [UIColor clearColor];
        self.backgroundColorForHighlighted = [UIColor clearColor];
        [self setBorder:[AppConst AppColor] width:1];
        [self setTitleColor:[AppConst AppColor] forState:UIControlStateNormal];
    }
    
    [self setTitle:titles[type] forState:UIControlStateNormal];
}




@end
