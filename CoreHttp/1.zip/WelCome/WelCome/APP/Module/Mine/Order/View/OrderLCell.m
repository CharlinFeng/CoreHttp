//
//  OrderLCell.m
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "OrderLCell.h"
#import "OrderBtn.h"
#import "OrderLModel.h"
#import "NSString+Extend.h"
#import "UIView+Extend.h"
#import "UITableViewCell+Extend.h"

@interface OrderLCell ()

@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UILabel *serviceLabel;
@property (weak, nonatomic) IBOutlet UILabel *locationLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet OrderBtn *actionBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineViewHC;

@property (nonatomic,assign) NSInteger type;


@end




@implementation OrderLCell

-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    
    //线条
    self.lineViewHC.constant = 0.5f;
    self.actionBtn.radius = 4;
    
}

-(void)dataFill:(OrderLModel *)orderLModel{

    _serviceLabel.text = orderLModel.service;
    _locationLabel.text = [NSString stringWithFormat:@"%@",orderLModel.address];
    _dateLabel.text = [NSString stringWithFormat:@"%@ ~ %@",[orderLModel.stime timestampToTimeStringWithFormatString:@"MM月dd日"],[orderLModel.etime timestampToTimeStringWithFormatString:@"MM月dd日"]];
    _actionBtn.type = orderLModel.status;
}


-(void)setFrame:(CGRect)frame{
    [super setFrame:[self cellMove:frame down:10]];
}

- (IBAction)actionBtnClick:(OrderBtn *)sender {
    
    
}



@end
