//
//  OrderDetail.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class OrderDetail: UIViewController {
    
    @IBOutlet weak var iconView: IconView!
    
    @IBOutlet weak var orderNOLabel: UILabel!
    
    @IBOutlet weak var orderTimeLabel: UILabel!
    
    @IBOutlet weak var orderStatusLabel: UILabel!
    
    @IBOutlet weak var servicePersonLabel: UILabel!
    
    @IBOutlet weak var orderContentLabel: UILabel!
    
    @IBOutlet weak var serviceDateLabel: UILabel!
    
    @IBOutlet weak var serviceMessageLabel: UILabel!
    
    @IBOutlet weak var cancelOrderBtn: UIButton!
    
    @IBOutlet weak var backToIndexBtn: UIButton!
    
    
    
    lazy var statusStrings = {["待处理","已经完成","已取消"]}()
    
    var orderModel: OrderLModel!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "订单详情"

        //头像
        iconView.imageView.imageWithUrlStr(orderModel.staffPhoto.resourceURL, phImage: nil)
        iconView.isVip = orderModel.staffVip == 1
        
        //订单编号
        orderNOLabel.text = orderModel.order_no
        
        //下单时间
        orderTimeLabel.text = orderModel.time.timestamp(format: "yyyy.MM.dd")
        
        //订单状态
        orderStatusLabel.text = statusStrings[orderModel.status]
        
        //服务人员
        servicePersonLabel.text = orderModel.trueName
        
        //订单内容
        orderContentLabel.text = orderModel.service
        
        //服务时间
        serviceDateLabel.text = orderModel.stime.timestamp(format: "MM.dd") + " - " + orderModel.etime.timestamp(format: "MM.dd")
        
        if orderModel.status != 0{cancelOrderBtn.hidden = true; backToIndexBtn.hidden=true}
    }
    
    @IBAction func orderCancelAction(sender: AnyObject) {
        
        let url = URL_CANCEL_ORDER.completeURL

        let user = UserModel.readSingleModelForKey(nil)
        
        let params = ["token":user.token, "orderID": orderModel.hostID]
        
        APPHttp.postUrl(url, params: params, target: self.view, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "取消成功", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: { () -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    
                    self.navigationController?.popViewControllerAnimated(true)
                })
            })
            
        }, errorBlock: nil)
    }
    
    @IBAction func backToIndexAction(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    
    
}
