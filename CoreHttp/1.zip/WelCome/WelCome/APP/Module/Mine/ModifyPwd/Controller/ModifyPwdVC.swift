//
//  ModifyPwdVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ModifyPwdVC: UIViewController {
    
    @IBOutlet weak var registerView: RegisterInputView!
    
    weak var oldPwdTF,newPwdTF1,newPwdTF2: UITextField!
    
    let userModel: UserModel = UserModel.readSingleModelForKey(nil)

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "修改密码"
        
        /** 处理注册视图 */
        registerViewHandle()
        
    }
    
    
    @IBAction func modifyAction(sender: AnyObject) {
        
        self.view.endEditing(YES)
        
        var errorMsg = UITextField.checkWithTFCheckModels {[unowned self] () -> [UITextField.TFCheckModel] in
            
            let m1 = UITextField.TFCheckModel(textField: self.oldPwdTF, desc: "原密码")
            let m2 = UITextField.TFCheckModel(textField: self.newPwdTF1, desc: "新密码")
            let m3 = UITextField.TFCheckModel(textField: self.newPwdTF2, desc: "确认密码")
            
            return [m1,m2,m3]
        }
        
        if newPwdTF1.text == oldPwdTF.text {errorMsg = "新旧密码一样"}
        
        if newPwdTF1.text != newPwdTF2.text {errorMsg = "再次输入的密码不一致"}
        
        
        
        if errorMsg.isNotEmpty {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: errorMsg, duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        let url = URL_MODIFY_PWD.completeURL

        let params = ["token": userModel.token,"pwd": (oldPwdTF.text as NSString).md5, "newPwd1": (newPwdTF1.text as NSString).md5, "newPwd2": (newPwdTF2.text as NSString).md5]
        
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "修改成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock:{
                
                self.navigationController?.popViewControllerAnimated(YES)
            })
        }, errorBlock: nil)
        
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        self.view.endEditing(YES)
    }
}
