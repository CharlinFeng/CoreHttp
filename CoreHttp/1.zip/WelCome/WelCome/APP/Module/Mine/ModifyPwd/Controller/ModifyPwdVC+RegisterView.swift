//
//  ModifyPwdVC+RegisterView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension ModifyPwdVC{
    
    
    /** 处理注册视图 */
    func registerViewHandle(){
        
        //模型准备
        let w1 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "原密码"), hasBottomBorder: YES))
        oldPwdTF = w1.textField
        
        let w2 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "新密码"), hasBottomBorder: YES))
        newPwdTF1 = w2.textField
        
        
        let w3 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "确认新密码"), hasBottomBorder: NO))
        newPwdTF2 = w3.textField
        
        
        //设置数据
        self.registerView.wrapViews = [w1,w2,w3]
        
        //注册通知
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "getVerifyBtnClick:", name:RegisterBtnClickNoti , object: nil)
    }

    
    
    
}







