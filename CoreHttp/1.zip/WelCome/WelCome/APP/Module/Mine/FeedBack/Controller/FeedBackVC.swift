//
//  FeedBackVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class FeedBackVC: AppVC {

    var type: VCType!
    
    @IBOutlet weak var textView: BaseTextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /** 提交 */
        submitPrepare()
    }
    

}
