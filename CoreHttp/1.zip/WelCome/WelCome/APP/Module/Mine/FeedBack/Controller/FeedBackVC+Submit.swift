//
//  FeedBackVC+Submit.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension FeedBackVC{
    
    
    
    /** 提交 */
    func submitPrepare(){
        
        let infoArr = [("意见反馈","输入产品意见，我们将不断优化体验。"),("用户留言","输入您想对来来说的话")]
        let info = infoArr[self.type.rawValue - 1]
        
        self.title = info.0
        textView.placeholder = info.1
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "提交", style: UIBarButtonItemStyle.Plain, target: self, action: "submitAction")
    }
    
    
    /** 提交数据 */
    func submitAction(){
        
        let content = textView.text
        
        if content.isEmpty{
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请输入内容", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        let url = URL_FEEDBACK.completeURL
        
        var params: [String: AnyObject] = ["type": type.rawValue,"content": content]
        
        let userModel = UserModel.readSingleModelForKey(nil)
        
        if userModel != nil{
            
            params["token"] = userModel.token
        }
        
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "提交成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: { () -> Void in
                
                self.navigationController?.popViewControllerAnimated(YES)
            })
            
            
        }, errorBlock: nil)
        
    }
    
}