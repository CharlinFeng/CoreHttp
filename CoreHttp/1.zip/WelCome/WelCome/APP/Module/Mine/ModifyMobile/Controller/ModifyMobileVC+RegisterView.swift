//
//  ModifyMobileVC+RegisterView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension ModifyMobileVC{
    
    var btnTag: Int {return 2}
    
    /** 处理注册视图 */
    func registerViewHandle(){
        
        self.mobileLabel.text = "当前手机号：" + userModel.phone
        
        //模型准备
        let w1 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Mobile(btnTag: btnTag), hasBottomBorder: YES))
        mobileTF = w1.textField
        mobileTF.keyboardType = UIKeyboardType.NumberPad
        
        let w2 = TFWrapView.wrapViewWithRegisterModel(RegisterInputModel(type: TFWrapView.TFWrapViewType.Text(text: "验证码"), hasBottomBorder: NO))
        
        codeTF = w2.textField
        codeTF.keyboardType = UIKeyboardType.NumberPad
        
        //设置数据
        self.registerView.wrapViews = [w1,w2]
        
        //注册通知
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "getVerifyBtnClick:", name:RegisterBtnClickNoti , object: nil)
        
    }
    
    /** 点击了获取验证码 */
    func getVerifyBtnClick(noti: NSNotification){
        
        if mobileTF.text == userModel.phone {
            
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "手机号码相同", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        //取出btn
        let btn = noti.object as! CoreCountBtn
        
        if btn.tag != btnTag {return}
        
        var errorMsg = ""
        
        let mobileCode = mobileTF.text
        
        if !((mobileCode as NSString).isMobileNO) {errorMsg = "手机号格式不正确"}
        if mobileCode.isEmpty {errorMsg = "请输入手机号"}
        
        if errorMsg.isNotEmpty {CoreToast.showMsgType(CoreToastMsgTypeError, msg: "错误", subMsg: errorMsg, timeInterval: 3.0, trigger: btn, apperanceBlock: nil, completionBlock: nil);return}
        
        btn.status = CoreCountBtnStatusCounting
        
        let url = URL_GET_CODE.completeURL
        
        let params = ["phone": mobileCode,"type":3]
        
        
        //        CoreSVP.showSVPWithType(CoreSVPTypeLoadingInterface, msg: "处理中", duration: 3.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
        
        
        //正式请求
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            let dict: [NSObject: AnyObject] = objectConvertToDictionay(data)!
            
            self.vid = dict["vid"] as! Int
            
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "短信下发成功", duration: 3.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            
            }, errorBlock: nil)
    }
    
    
}