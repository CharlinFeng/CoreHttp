//
//  ModifyMobileVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ModifyMobileVC: UIViewController {
    
    @IBOutlet weak var registerView: RegisterInputView!
    
    @IBOutlet weak var mobileLabel: UILabel!
    
    weak var mobileTF,codeTF: UITextField!
    
    var vid: Int!
    
    let tag = 2
    
    //显示当前手机号
    let userModel = UserModel.readSingleModelForKey(nil)
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.title = "修改手机号"
        
        /** 处理注册视图 */
        registerViewHandle()
    }
    
    
    
    
    
    
    @IBAction func modifyAction(btn: AnyObject) {
        
        if mobileTF.text == userModel.phone {
        
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "手机号码相同", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        if self.vid == nil {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请先获取验证码", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        
        let errorMsg = UITextField.checkWithTFCheckModels {[unowned self] () -> [UITextField.TFCheckModel] in
            
            let m1 = UITextField.TFCheckModel(textField: self.mobileTF, desc: "手机号")
            let m2 = UITextField.TFCheckModel(textField: self.codeTF, desc: "验证码")
            
            return [m1,m2]
        }
        
        if errorMsg.isNotEmpty {
        
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: errorMsg, duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: nil)
            return
        }
        
        let url = URL_MODIFY_MOBILE.completeURL

        let params = ["token":userModel.token,"phone":mobileTF.text,"oldPhone":userModel.phone,"verify":codeTF.text,"vid":vid]
        
        APPHttp.postUrl(url, params: params, target: nil, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "修改成功", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock:{
            
                self.navigationController?.popViewControllerAnimated(YES)
            })
            
        }, errorBlock: nil)
        
    }

    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        self.view.endEditing(YES)
    }
    

}
