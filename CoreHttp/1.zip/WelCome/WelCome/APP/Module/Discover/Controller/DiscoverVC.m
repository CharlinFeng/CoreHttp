//
//  DiscoverVC.m
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "DiscoverVC.h"
#import "DiscoverModel.h"
#import "DiscoverCell.h"
#import "SVWebViewController.h"
#import "WelCome-Swift.h"

@interface DiscoverVC ()

@end

@implementation DiscoverVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"发现";
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    DiscoverModel *discoverModel = self.dataList[indexPath.item];
    
    SVWebViewController *webVC = nil;
    
    //创建
    if (discoverModel.content_type == 1){ // url
        webVC = [[SVWebViewController alloc] initWithAddress:discoverModel.content_url];
    }else{
        webVC = [[SVWebViewController alloc] init];
        [webVC.webView loadHTMLString:discoverModel.content_str baseURL:nil];
        webVC.title = discoverModel.title;
    }
    
    [self.navigationController pushViewController:webVC animated:YES];
}




/** 协议方法区 */


/** 刷新方式 */
-(ListVCRefreshAddType)listVC_RefreshType{
    return ListVCRefreshAddTypeBoth;
}


/** 模型类 */
-(Class)listVC_Model_Class{
    return [DiscoverModel class];
}


/** 视图类 */
-(Class)listVC_View_Cell_Class{
    return [DiscoverCell class];
}


/** 请求参数 */
-(NSDictionary *)listVC_Request_Params{
    
    return nil;
    
    NSInteger cityID = [[AppCityModel sharedInstance] getCurrentCityForOC];
    
    return @{@"cityID":@(cityID)};
}


/** 是否移除回到顶部按钮 */
-(BOOL)listVC_Remove_Back2Top_Button{
    return NO;
}


/** tableViewController */
/** cell的行高：tableViewController专用 */
-(CGFloat)listVC_CellH4IndexPath:(NSIndexPath *)indexPath{
    return 118 + 10;
}

/** 无本地FMDB缓存的情况下，需要在ViewDidAppear中定期自动触发顶部刷新事件 */
-(NSString *)listVC_Update_Delay_Key{
    return NSStringFromClass(self.class);
}


/** 无缓存定期更新周期 */
-(NSTimeInterval)listVC_Update_Delay_Time{
    return 30;
}

/** 是否关闭返回顶部功能 */
-(BOOL)removeBack2TopBtn{
    return NO;
}


@end
