//
//  DiscoverVC.h
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "CoreListTableViewController.h"

@interface DiscoverVC : CoreListTableViewController

@end
