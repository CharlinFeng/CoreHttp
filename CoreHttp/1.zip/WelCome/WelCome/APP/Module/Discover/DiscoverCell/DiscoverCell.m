//
//  DiscoverCell.m
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "DiscoverCell.h"
#import "DiscoverModel.h"
#import "UIImage+Color.h"
#import "WelCome-Swift.h"
#import "UIImageView+SD.h"
#import "UITableViewCell+Extend.h"

@interface DiscoverCell ()

@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@property (weak, nonatomic) IBOutlet UILabel *mainLabel;

@property (weak, nonatomic) IBOutlet UILabel *subLabel;

@property (weak, nonatomic) IBOutlet UIButton *extensionBtn;



@end



@implementation DiscoverCell


-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    [self.extensionBtn setBackgroundImage:[[UIImage imageNamed:@"popularize"] imageWithGradientTintColor:[AppConst AppColor]] forState:UIControlStateNormal];
}


-(void)dataFill:(DiscoverModel *)discoverModel{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        //处理按钮
        self.extensionBtn.hidden = discoverModel.type == 0;
        
        //图片
        [self.imageV imageWithUrlStr:discoverModel.photo.resourceURL phImage:nil];
        
        //文字
        self.mainLabel.text = discoverModel.title;
        self.subLabel.text = discoverModel.subtitle;
    });
    
}


-(void)setFrame:(CGRect)frame{
    
    [super setFrame:[self cellMove:frame down:10]];
}






@end
