//
//  DiscoverModel.h
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"

@interface DiscoverModel : BaseModel

@property (nonatomic,copy) NSString *title,*subtitle,*content_url,*content_str,*photo;

@property (nonatomic,assign) NSInteger content_type,type;


@end
