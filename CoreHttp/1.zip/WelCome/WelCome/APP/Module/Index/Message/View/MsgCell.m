//
//  MsgCell.m
//  WelCome
//
//  Created by 冯成林 on 15/8/4.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "MsgCell.h"
#import "MsgModel.h"
#import "UIImage+Color.h"
#import "UIImage+FixOrientation.h"
#import "UIView+Extend.h"

@interface MsgCell ()

@property (weak, nonatomic) IBOutlet UIView *redDotView;

@property (weak, nonatomic) IBOutlet UILabel *msgTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *msgDetailLabel;

@property (weak, nonatomic) IBOutlet UIImageView *idvImgV;


@end



@implementation MsgCell

-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    //右边的前头
    self.idvImgV.image = [[[UIImage imageNamed:@"return"] imageWithGradientTintColor:hexColor(595757)] rotate:M_PI];
    
    self.redDotView.radius = 5;
}




-(void)dataFill:(MsgModel *)msgModel{
    
    self.redDotView.hidden = msgModel.status != 0;
    
    self.msgTitleLabel.text = msgModel.title;
    
    self.msgDetailLabel.text = msgModel.subtitle;
}




@end
