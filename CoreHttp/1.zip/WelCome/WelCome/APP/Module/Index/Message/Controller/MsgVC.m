//
//  MsgVCViewController.m
//  WelCome
//
//  Created by 冯成林 on 15/8/4.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "MsgVC.h"
#import "MsgModel.h"
#import "MsgCell.h"
#import "SVWebViewController.h"
#import "UIColor+Extend.h"
#import "UserModel.h"
#import "APPHttp.h"

@interface MsgVC ()

@end

@implementation MsgVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"消息列表";
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 15, 0, 15);
    self.tableView.separatorColor = hexColor(d8d8d9);
}


-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];

    [self headerRefreshAction];
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    MsgModel *msgModel = self.dataList[indexPath.item];
    
    SVWebViewController *webVC = nil;
    
    //创建
    if (msgModel.type == 1){ // url
        webVC = [[SVWebViewController alloc] initWithAddress:msgModel.link_url];
    }else{
        webVC = [[SVWebViewController alloc] init];
        [webVC.webView loadHTMLString:msgModel.content baseURL:nil];
        webVC.title = msgModel.title;
    }
    
    [self.navigationController pushViewController:webVC animated:YES];
    
    NSString *url = @"http://211.149.151.92/lailai/MyApi/readMessage";
    
    UserModel *userModel = [UserModel readSingleModelForKey:nil];
    
    NSDictionary *params = @{@"token":userModel.token,@"messageID": @(msgModel.message_id)};
    
    [APPHttp postUrl:url params:params target:nil type:APPHttpTypeNone success:^(id obj) {
        
    } errorBlock:nil];
}




/** 协议方法区 */


/** 刷新方式 */
-(ListVCRefreshAddType)listVC_RefreshType{
    return ListVCRefreshAddTypeBoth;
}


/** 模型类 */
-(Class)listVC_Model_Class{
    return [MsgModel class];
}


/** 视图类 */
-(Class)listVC_View_Cell_Class{
    return [MsgCell class];
}

-(NSDictionary *)listVC_Request_Params{
    
    UserModel *userModel = [UserModel readSingleModelForKey:nil];
    
    return @{@"token":userModel.token};
}


/** 是否移除回到顶部按钮 */
-(BOOL)listVC_Remove_Back2Top_Button{
    return NO;
}


/** tableViewController */
/** cell的行高：tableViewController专用 */
-(CGFloat)listVC_CellH4IndexPath:(NSIndexPath *)indexPath{
    return 58;
}

/** 无本地FMDB缓存的情况下，需要在ViewDidAppear中定期自动触发顶部刷新事件 */
-(NSString *)listVC_Update_Delay_Key{
    return NSStringFromClass(self.class);
}


/** 无缓存定期更新周期 */
-(NSTimeInterval)listVC_Update_Delay_Time{
    return 30;
}

/** 是否关闭返回顶部功能 */
-(BOOL)removeBack2TopBtn{
    return NO;
}
@end
