//
//  MsgModel.h
//  WelCome
//
//  Created by 冯成林 on 15/8/4.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"

@interface MsgModel : BaseModel

@property (nonatomic,assign) NSInteger message_id,uid,status,mid,type;

@property (nonatomic,copy) NSString *title,*subtitle,*link_url,*content,*c_time;

@end
