//
//  MsgCell.h
//  WelCome
//
//  Created by 冯成林 on 15/8/4.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface MsgCell : BaseTableViewCell

@end
