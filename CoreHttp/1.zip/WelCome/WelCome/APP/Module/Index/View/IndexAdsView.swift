//
//  IndexAdsView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/14.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class IndexAdsView: UIView {

 
    @IBOutlet private var btns: [UIButton]!
    
    /** 模型数据 */
    var models: [ShowModel]?{ didSet{ self.dataFill() } }
    
    /** 事件回调 */
    var btnClickClosure: ((index: Int, showModel: ShowModel) -> Void)?
    
    override func awakeFromNib() {
        
        //设置边框
        btns.enumerate { (index, btn: UIButton) -> Void in
            
            btn.setBorder(hexColor("cecfcf"), width: 1.0)
        }
        
        
    }
    
    
    /** 事件 */
    
    @IBAction func btnClick(sender: UIButton) {
        
        if btnClickClosure == nil {return}
        
        let index = sender.tag
        
        if index >= models?.count {return}
        
        btnClickClosure!(index: index, showModel: models![index])
    }
    
    
    /** 数据填充 */
    func dataFill(){
        
        if models == nil {return}
        println(models?.count)
        models!.enumerate({ (index: Int, showModel: ShowModel) -> Void in
            
            if index < 2 {
                
                println(showModel.photo.resourceURL)
                self.btns[index].imageWithUrlStr(showModel.photo.resourceURL, phImage: nil)
            }
            
        })
    }
    
    
}
