//
//  CityBarButton.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

extension IndexVC{
    
    
    /** 城市按钮 */
    class CityButton: UIButton {

        let imageW: CGFloat = 11
        
        required init(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        /** 视图准备 */
        func viewPrepare(){
            
            self.setTitle("请选择", forState: UIControlState.Normal)
            
            self.setImage(UIImage(named: "down_arrow"), forState: UIControlState.Normal)
            
            //设置字体
            self.titleLabel?.font = UIFont.systemFontOfSize(16)
            self.imageView?.contentMode = UIViewContentMode.Center
            self.adjustsImageWhenHighlighted = NO
            self.setTitleColor(rgb(181, 181, 181, 1), forState: UIControlState.Highlighted)
            
            //注册通知
            NSNotificationCenter.defaultCenter().addObserver(self, selector: "locationedCity:", name: AppCityModelGetedCityNoti, object: nil)
        }
        
        
        /** 定位到城市 */
        func locationedCity(noti: NSNotification){
            
            //取出城市模型
            let cityModel = noti.userInfo?["cityModel"] as! CFCityPickerVC.CityModel
            
            showCityWithCityModel(cityModel)
        }
        
        
        /** 展示城市数据 */
        func showCityWithCityModel(cityModel: CFCityPickerVC.CityModel){
            self.setTitle("\(cityModel.name)市", forState: UIControlState.Normal)
        }
        
        
        //调整位置
        override func titleRectForContentRect(contentRect: CGRect) -> CGRect {
            
            let x: CGFloat = 0
            let y: CGFloat = 0
            let width = contentRect.size.width - imageW
            let height = contentRect.size.height
            return CGRectMake(x, y, width, height)
        }
        
        override func imageRectForContentRect(contentRect: CGRect) -> CGRect {
        
            let x: CGFloat = contentRect.size.width - imageW
            let y: CGFloat = 0
            let width = imageW
            let height = contentRect.size.height
            return CGRectMake(x, y, width, height)
        }
        
        
    }
    
    
    /** 信息按钮 */
    class MessageBtn: UIButton {
    
        required init(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        /** 视图准备 */
        func viewPrepare(){
            
            self.setImage(UIImage(named: "message"), forState: UIControlState.Normal)
        }
        
        
    }
    
    /** 搜索框 */
    class SearchBar: UISearchBar,UISearchBarDelegate {
        
        
        var searchClosure: ((searText: String) -> Void)!
        
        lazy var zoomImageView: UIImageView = {
            
            let imageV = UIImageView(image: UIImage(named: "search"))
            imageV.contentMode = UIViewContentMode.ScaleAspectFit
            return imageV
            }()
    
        let zoomImageViewWidth: CGFloat = 14
        required init(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            /** 视图准备 */
            self.viewPrepare()
        }
        
        /** 视图准备 */
        func viewPrepare(){
            self.placeholder = "搜索"
            
            self.setImage(UIImage(), forSearchBarIcon: UISearchBarIcon.Search, state: UIControlState.Normal)
            self.addSubview(zoomImageView)
            self.delegate = self
        }
        
        
        override func layoutSubviews() {
            super.layoutSubviews()
            println(self.subviews)
            
            let x = self.bounds.size.width - zoomImageViewWidth - 20
            let y: CGFloat = 0
            let width = zoomImageViewWidth
            let height = self.bounds.size.height
            zoomImageView.frame = CGRectMake(x, y, width, height)
        }
        
        func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
            
            if searchText.isEmpty {
                
                self.addSubview(zoomImageView)
            }else{
                zoomImageView.removeFromSuperview()
            }
        }
        
        func searchBarSearchButtonClicked(searchBar: UISearchBar) {
            searchClosure?(searText: searchBar.text)
            searchBar.endEditing(YES)
        }
    }
    
    
    
    

}

