//
//  IndexMeauCell.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/15.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class IndexMeauCell: BaseCollectionViewCell {
    
    
    @IBOutlet private weak var imageV: UIImageView!
    @IBOutlet private weak var nameLabel: UILabel!
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.radius = 4
    }
    
    override func dataFill(baseModel: BaseModel) {
    
        //类型强转
        let meauModel = baseModel as! IndexMeauModel
        
        //图片
        imageV.image = UIImage(named: meauModel.imageName)
        
        //标题
        nameLabel.text = meauModel.nameText
        //背景色
        self.backgroundColor = hexColor(meauModel.bgColor)
        
    }

}
