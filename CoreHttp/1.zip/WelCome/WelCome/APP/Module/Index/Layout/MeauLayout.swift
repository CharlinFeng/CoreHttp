//
//  MeauLayout.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/15.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class MeauLayout: UICollectionViewLayout {
   
//    let sectionInsets: UIEdgeInsets = UIEdgeInsetsMake(9, 9, 9, 9)
    let colMargin: CGFloat = 9
    let rowMargin: CGFloat = 9
    let row = 2
    let count = 4
    
    var attrs: [UICollectionViewLayoutAttributes]?
    
    lazy var heights: [CGFloat] = {
    
        var hts: [CGFloat] = [185,136,88,137]
        
        var point: CGFloat = 1.0
        if iPhone4x_320_480() {point = 0.69}
        if iPhone6_375_667() {point = 1.28}
        if iPhone6Plus_414_736_Portait() {point = 1.46}
        
        
        let newHts = hts.map{$0 * point}
        
        return newHts
    }()
    
    override func prepareLayout() {
        
        var attrsM: [UICollectionViewLayoutAttributes] = []
        
        for (var i=0; i<count; i++){
            
            //得到每列的attr
            let attr = self.layoutAttributesForItemAtIndexPath(NSIndexPath(forItem: i, inSection: 0))
            
            attrsM.append(attr)
        }

        attrs = attrsM
    }
    
    override func collectionViewContentSize() -> CGSize {
        
        let width = Screen.width
        let height = heights[0] + heights[2] + rowMargin * 2
        
        return CGSizeMake(width, height)
    }
    
    override func shouldInvalidateLayoutForBoundsChange(newBounds: CGRect) -> Bool {
        return YES
    }
    
    override func layoutAttributesForItemAtIndexPath(indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes! {
        
        //创建attr
        let attr = UICollectionViewLayoutAttributes(forCellWithIndexPath: indexPath)
        
        let width = (Screen.width - rowMargin * (row + 1).toCGFloat) / row.toCGFloat
        
        let item = indexPath.item
        
        let currentRow = item % 2
        
        let currentCol = item / 2
        
        let x = rowMargin * (currentRow + 1).toCGFloat + currentRow.toCGFloat * width
        
        var lastItemHeight: CGFloat = 0
        
        if(item >= 2) {lastItemHeight = heights[item-2]}
        
        let y = colMargin * (currentCol + 1).toCGFloat + lastItemHeight
        
        let frame = CGRectMake(x, y, width, heights[item])
        
        attr.frame = frame
        
        return attr
    }
    
    /** 处理所有的属性 */
    override func layoutAttributesForElementsInRect(rect: CGRect) -> [AnyObject]? {

        return attrs
    }
}
