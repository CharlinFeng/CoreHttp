//
//  ExpView.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ExpView: UIView {
    
    @IBOutlet weak var tableView: UITableView!
    
    var dataList: [ServiceDetailModel.Record]!{didSet{dataComing()}}
    
    let itemH: CGFloat = 60
}

extension ExpView: UITableViewDataSource,UITableViewDelegate{
    
    func dataComing(){
        let h = dataList == nil || dataList.count == 0 ? 40 : itemH * CGFloat(dataList.count)
        self.make_height(equal: h)
        tableView.reloadData()
        
    }
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.separatorInset = UIEdgeInsetsMake(0, 16, 0, 16)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if dataList == nil {return 0}
        return dataList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = ExpViewCell.reuseCell(tableView)
        cell.model = dataList[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return itemH
    }
    
}
