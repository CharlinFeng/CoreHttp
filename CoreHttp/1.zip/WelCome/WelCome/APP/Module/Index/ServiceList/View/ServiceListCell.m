//
//  ServiceListCell.m
//  WelCome
//
//  Created by 冯成林 on 15/8/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "ServiceListCell.h"
#import "WelCome-Swift.h"
#import "ServiceListModel.h"
#import "UIImageView+SD.h"
#import "TagView.h"
#import "StarView.h"

@interface ServiceListCell ()

@property (weak, nonatomic) IBOutlet IconView *iconView;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UILabel *descLabel;

@property (weak, nonatomic) IBOutlet UIButton *priceBtn;

@property (weak, nonatomic) IBOutlet TagView *topTagView;

@property (weak, nonatomic) IBOutlet TagView *midTagView;

@property (weak, nonatomic) IBOutlet StarView *starView;

@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;




@end


@implementation ServiceListCell


-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    self.topTagView.margin = 4;
    self.topTagView.fontPoint = 13;
    
    self.midTagView.margin = 3;
    self.midTagView.fontPoint = 12;
    
    [self.cancelBtn setBorder:hexColor(e94e50) width:1];
    self.cancelBtn.radius = 4;
}





-(void)dataFill:(ServiceListModel *)listModel{
    
    //头像
    [_iconView.imageView imageWithUrlStr:listModel.photo.resourceURL phImage:nil];
    
    //是否是vip
    _iconView.isVip = listModel.for_vip;
    
    //名字
    _nameLabel.text = listModel.name;
    
    //描述
    _descLabel.text = listModel.signature;
    
    //价格
    [_priceBtn setTitle:listModel.service_price forState:UIControlStateNormal];
    
    //topTagView传递数据
    self.topTagView.serviceItemModels = listModel.serviecArr;

    //midTagView传递数据
    NSMutableArray *markArrM = [NSMutableArray array];

    ServiceItemModel *sexModel = [ServiceItemModel modelWithName:listModel.sex == 1 ? @"男" : @"女" bgColor:@"ed788d"];
    
    ServiceItemModel *ageModel = [ServiceItemModel modelWithName:[NSString stringWithFormat:@"%@",@(listModel.age)] bgColor:@"f8b325"];
    
    [markArrM addObjectsFromArray:@[sexModel,ageModel]];
    if (listModel.markArr.count !=0) {[markArrM addObjectsFromArray:listModel.markArr];}
    
    self.midTagView.serviceItemModels = markArrM;
    
    //星级
    self.starView.value = listModel.star;
    
}




-(void)setShowCancelBtn:(BOOL)showCancelBtn{
    
    _showCancelBtn = showCancelBtn;
    
    if (showCancelBtn){
        self.cancelBtn.hidden = NO;
    }
    
}


- (IBAction)cancelBtnClick:(id)sender {
    
    if(self.ClickCancelBtnBlock != nil) self.ClickCancelBtnBlock(self.baseModel);
}








@end
