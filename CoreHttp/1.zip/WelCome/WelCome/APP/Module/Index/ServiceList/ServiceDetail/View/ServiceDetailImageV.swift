//
//  ServiceDetailImageV.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ServiceDetailImageV: UIImageView {


    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    /** 视图准备 */
    func viewPrepare(){
        
        self.radius = 7
        self.backgroundColor = UIColor.grayColor()
    }
    
    
    
    
    

}
