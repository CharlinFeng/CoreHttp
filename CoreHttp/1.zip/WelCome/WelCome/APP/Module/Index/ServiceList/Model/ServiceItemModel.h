//
//  ServiceItemModel.h
//  WelCome
//
//  Created by 冯成林 on 15/8/10.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"
#import "NSObject+MJKeyValue.h"

@interface ServiceItemModel : BaseModel

@property (nonatomic,copy) NSString *name,*bg_color;

@property (nonatomic,assign) BOOL needBorder;

+(instancetype)modelWithName:(NSString *)name bgColor:(NSString *)bg_color;


@end
