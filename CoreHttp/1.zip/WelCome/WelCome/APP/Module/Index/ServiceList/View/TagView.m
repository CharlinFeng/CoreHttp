//
//  TagView.m
//  WelCome
//
//  Created by 冯成林 on 15/8/17.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "TagView.h"
#import "ServiceItemModel.h"
#import "UIColor+Extend.h"
#import "WelCome-Swift.h"

@implementation TagView


-(void)setServiceItemModels:(NSArray *)serviceItemModels{
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    _serviceItemModels = serviceItemModels;
    
    UIControlState state = UIControlStateNormal;
    
    [serviceItemModels enumerateObjectsUsingBlock:^(ServiceItemModel *itemModel, NSUInteger idx, BOOL *stop) {
        
        UILabel *label = [[UILabel alloc] init];
        
        label.text = itemModel.name;
        
        label.font = [UIFont systemFontOfSize:self.fontPoint];
        
        if (!itemModel.needBorder){
            label.backgroundColor = [UIColor colorWithHexColorString:itemModel.bg_color];
            label.textColor = [UIColor whiteColor];
        }else{
            label.textColor =  [AppConst AppColor];
            label.layer.borderColor = [AppConst AppColor].CGColor;
        }
        
        [self addSubview:label];
        
        label.layer.cornerRadius = 2;
        
        label.layer.masksToBounds = YES;
        
        label.textAlignment = NSTextAlignmentCenter;
        
    }];
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}



-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    if (self.subviews == nil || self.subviews.count == 0) return;
    
    CGFloat height = self.bounds.size.height;
    if (self.needMultiRow) height = self.fontPoint + 10;
    
    __block CGFloat y = 0;
    
    [self.subviews enumerateObjectsUsingBlock:^(UILabel *label, NSUInteger idx, BOOL *stop) {
        
        CGFloat x = 0;
        
        if (idx > 0){x = CGRectGetMaxX([self.subviews[idx-1] frame]) + self.margin;}
        
        if (idx > 0){y = CGRectGetMinY([self.subviews[idx-1] frame]);}
        
        CGFloat width = [label.text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:self.fontPoint]}].width + 10;
        
        
        if (!self.needMultiRow) { //单行
            
    
            label.frame = CGRectMake(x, y, width, height);
            
        }else { //多行
            
            
            CGRect frame = CGRectMake(x, y, width, height);
            
            if (CGRectGetMaxX(frame) > self.maxWidth) { //过宽
                
                frame.origin.x = 0;
                frame.origin.y = CGRectGetMaxY([self.subviews[idx-1] frame]) + self.margin;
            }
            label.frame = frame;
            
            if (idx == self.subviews.count - 1){
            
                if(self.HeightCalBlock!=nil)self.HeightCalBlock(CGRectGetMaxY(frame));
            }
            
            if (self.borderColor != nil) {
                
                label.textColor = [AppConst AppColor];
                label.backgroundColor = [UIColor clearColor];
               
                [label borderWithWidth:1 color:[AppConst AppColor]];
            }
        }
        
        
    }];
}

-(CGFloat)margin{if (_margin == 0){_margin = 2;}return _margin;}

-(CGFloat)fontPoint{if(_fontPoint == 0 ){_fontPoint = 12;} return _fontPoint;}


@end
