//
//  ServiceDetailVC+Exp.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



extension ServiceDetailVC{
    

    /** 个人履历 */
    func expPrepare(){
        

        contentView.addSubview(expView)
        
        expView.make_relation(sd: 0, v: hobbyView, vd: 2, o: -5)
        expView.make_relation(sd: 1, v: nil, vd: 1, o: 0)
        expView.make_relation(sd: 3, v: nil, vd: 3, o: 0)

    }
    
    /** 个人履历 */
    func expDataFill(model: ServiceDetailModel){
        
        expView.dataList = model.record
        
        
    }
    
}