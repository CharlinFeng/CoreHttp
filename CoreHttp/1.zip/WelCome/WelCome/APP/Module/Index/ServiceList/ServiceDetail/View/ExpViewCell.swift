//
//  ExpViewCell.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ExpViewCell: CFCell {
    
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    @IBOutlet weak var label3: UILabel!
    
    @IBOutlet weak var label4: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        
        label1.setBorder(AppConst.AppColor, width: 1)
        label1.radius = 4
        
        label2.setBorder(AppConst.AppColor, width: 1)
        label2.radius = 4
    }
    
    
    override func dataFill() {
        
        if model == nil {return}

        let expModel = model as! ServiceDetailModel.Record
        
        label1.text = " "+expModel.stime.timestamp(format: "yyyy年-MM月")+" "
        label2.text = " "+expModel.etime.timestamp(format: "yyyy年-MM月")+" "
        label3.text = expModel.addr
        label4.text = expModel.happen
    }
    
}
