//
//  ServiceDetailModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/26.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

class ServiceDetailModel: Reflect {
   
    var name,signature,sign,common_interest,c_time,truename,phone,desc: String!
    var id,sex,age,star,service_price,price_unit,stature,weight,for_vip,active,status,del,online,collect,modelType: NSNumber!
    var imgData: [ImgData]!
    var otherImgData: [ImgData]!
    var interestArr: [String]!
    var serviceRecord: [ServiceRecord]!
    var certificate: [Certificate]!
    var serviceListArr: [ServiceListArr]!
    var serviceCityArr: [ServiceCityArr]!
    var record: [Record]!
    var markArr: [MarkArr]!
    override func mappingDict() -> [String : String]? {
        return ["desc":"description","modelType":"type"]
    }
}

extension ServiceDetailModel{
    class ImgData: Reflect{var photo,thumb_photo: String!}
    class ServiceRecord: Reflect {var time,content: String!}
    class Certificate: Reflect {
        var staffCertificateID,name,desc: String!
        var checked,sid,id,upload: NSNumber!
        override func mappingDict() -> [String : String]? {
            return ["desc":"description"]
        }
    }
    class ServiceListArr: Reflect {
        var id,sid,serviceID,isRequired: NSNumber!
        var name,bg_color: String!

    }
    class ServiceCityArr: Reflect{
        var id,staff_id,city_id: NSNumber!
        var name: String!
    }
    class Record: Reflect {
        var id,sid: NSNumber!
        var stime,etime,addr,happen,c_time: String!
    }
    class MarkArr: Reflect {
        var id,sid: NSNumber!
        var content,c_time: String!
    }
}


extension ServiceDetailModel{
    
    /** 请求数据 */
    class func getData(target: AnyObject!,params: [String: AnyObject] ,data:((model: ServiceDetailModel)->Void)){
        
        let url = URL_SERVICE_DETAIL.completeURL
        
        APPHttp.postUrl(url, params: params, target: target, type: APPHttpTypeStatusView, success: { (d) -> Void in
            
            let sdm = ServiceDetailModel.parse(dict: d as! NSDictionary)
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                data(model: sdm)
            })
            
        }, errorBlock: nil)
    }
}

