//
//  ServiceItemModel.m
//  WelCome
//
//  Created by 冯成林 on 15/8/10.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "ServiceItemModel.h"

@implementation ServiceItemModel

+(instancetype)modelWithName:(NSString *)name bgColor:(NSString *)bg_color{
    
    ServiceItemModel *itemModel = [[ServiceItemModel alloc] init];
    
    itemModel.name = name;
    itemModel.bg_color = bg_color;
    
    return itemModel;
}

@end
