//
//  ServiceDetailVC+Sign+Name.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



/** 个性签名+真实姓名 */
extension ServiceDetailVC{
    
    func signNameViewPrepare(){
        
        let height = 57
        
        
        signView.mainLabel.text = "个性签名"
        
        contentView.addSubview(signView)
        
        signView.snp_makeConstraints { (make) -> Void in
            
            make.top.equalTo(tagContentView.snp_bottom).offset(5)
            make.leading.equalTo(signView.superview!.snp_leading)
            make.trailing.equalTo(signView.superview!.snp_trailing)
            make.height.equalTo(height)
        }
        
        
        contentView.addSubview(nameView)
        
        nameView.mainLabel.text = "真实姓名"
        nameView.snp_makeConstraints { (make) -> Void in
            
            make.top.equalTo(signView.snp_bottom).offset(5)
            make.leading.equalTo(signView.superview!.snp_leading)
            make.trailing.equalTo(signView.superview!.snp_trailing)
            make.height.equalTo(height)
        }
        
    }
    
    /** 签名数据填充 */
    func signDataFill(model: ServiceDetailModel){
        
        signView.descLabel.text = model.signature
        nameView.descLabel.text = (model.name as NSString).substringToIndex(1) + "**" + " (下单可见)"
        
    }
    
}