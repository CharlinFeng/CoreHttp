//
//  ServiceDetailVC+Hobby.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



extension ServiceDetailVC{
    
    
    /** 爱好准备 */
    func hobbyPrepare(){
        
        hobbyView.name = "兴趣爱好"
        
        var items: [ServiceItemModel] = []
        
        for (var i=0; i<7; i++){
            
            let item = ServiceItemModel(name: "爱好\(i)", bgColor: "ed788d")
            item.needBorder = true
            items.append(item)
        }
        
        contentView.addSubview(hobbyView)
        
        hobbyView.make_relation(sd: 0, v: recordView, vd: 2, o: -5)
        hobbyView.make_relation(sd: 1, v: nil, vd: 1, o: 0)
        hobbyView.make_relation(sd: 3, v: nil, vd: 3, o: 0)
    }
    
    /** 证书准备 */
    func certificatePrepare(){
        
        certificateView.name = "证书认证"
        
        var items: [ServiceItemModel] = []
        
        for (var i=0; i<5; i++){
            
            let item = ServiceItemModel(name: "证书\(i)", bgColor: "ed788d")
            item.needBorder = true
            items.append(item)
        }
        
        
        contentView.addSubview(certificateView)
        
        certificateView.make_relation(sd: 0, v: expView, vd: 2, o: -5)
        certificateView.make_relation(sd: 1, v: nil, vd: 1, o: 0)
        certificateView.make_relation(sd: 3, v: nil, vd: 3, o: 0)

    }
    
    
    /** 地点准备 */
    func locationViewPrepare(){
        
        locationView.name = "服务地点"
        
        var items: [ServiceItemModel] = []
        
        for (var i=0; i<2; i++){
            
            let item = ServiceItemModel(name: "地点\(i)", bgColor: "ed788d")
            item.needBorder = true
            items.append(item)
        }
        
        
        contentView.addSubview(locationView)
        
        locationView.make_relation(sd: 0, v: certificateView, vd: 2, o: -5)
        locationView.make_relation(sd: 1, v: nil, vd: 1, o: 0)
        locationView.make_relation(sd: 3, v: nil, vd: 3, o: 0)
    }
    
    
    /** 兴趣爱好 */
    func hobbyDataFill(model: ServiceDetailModel){
        
        certificateDataFill(model)
        locationDataFill(model)
        
        let isEmpty = model.interestArr?.count == 0
        
        if isEmpty{
            hobbyView.make_height(equal: 50)
            return;
        }
        
        
        var items: [ServiceItemModel] = []
        
        model.interestArr.enumerate { (index, value) -> Void in
            
            let item = ServiceItemModel(name: value, bgColor: "000000")
            item.needBorder = true
            items.append(item)
        }
        
        hobbyView.tagView.serviceItemModels = items;
    }
    
    
    
    /** 证书 */
    func certificateDataFill(model: ServiceDetailModel){
        
        
        let isEmpty = model.certificate?.count == 0
        
        if isEmpty{
            certificateView.make_height(equal: 50)
            return;
        }
        
        
        var items: [ServiceItemModel] = []
        
        model.certificate.enumerate { (index, value) -> Void in
            
            let item = ServiceItemModel(name: value.name, bgColor: "000000")
            item.needBorder = true
            items.append(item)
        }
        
        certificateView.tagView.serviceItemModels = items;
        certificateItems = items
    }
    
    /** 地点爱好 */
    func locationDataFill(model: ServiceDetailModel){
        
        
        let isEmpty = model.serviceCityArr?.count == 0
        
        if isEmpty{
            locationView.make_height(equal: 50)
            return;
        }
        
        
        var items: [ServiceItemModel] = []
        
        model.serviceCityArr.enumerate { (index, value) -> Void in
            
            let item = ServiceItemModel(name: value.name, bgColor: "000000")
            item.needBorder = true
            items.append(item)
        }
        
        locationView.tagView.serviceItemModels = items;
    }
    
    
    
}