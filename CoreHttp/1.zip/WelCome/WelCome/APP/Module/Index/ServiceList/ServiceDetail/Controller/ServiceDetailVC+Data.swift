//
//  ServiceDetailVC+Data.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/26.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension ServiceDetailVC{
    
    /** 处理数据 */
    func dataPrepare(){
        
        let params = ["staffID":staffID,"menu_type": meauType]
        
        ServiceDetailModel.getData(view, params:params, data: {(model) -> Void in
            println(model)
            self.model = model

            CoreViewNetWorkStausManager.dismiss(self.view, animated: true)
            
            /** 展示头像数据 */
            self.headImage(model)
            
            /** 展示tag数据 */
            self.tagFill(model)
            
            /** 签名数据填充 */
            self.signDataFill(model)
            
            /** 服务记录 */
            self.recordDataFill(model)
            
            /** 兴趣爱好 */
            self.hobbyDataFill(model)
            
            /** 个人履历 */
            self.expDataFill(model)
            
        })
    }
}

extension ServiceDetailVC{
    
    /** 展示头像数据 */
    func headImage(model: ServiceDetailModel){

        mainImageV.imageWithUrlStr(model.imgData[0].thumb_photo.resourceURL, phImage: nil)
        
        if model.otherImgData != nil {
            
            /** 数组遍历 */
            for (index: Int, other: ServiceDetailModel.ImgData) in enumerate(model.otherImgData){
                
                thunbnailImageVs[index].imageWithUrlStr(model.otherImgData[index].photo.resourceURL, phImage: nil)
            }
        }
    }
    
    
}

