//
//  ServiceDetailVC+Collect.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



extension ServiceDetailVC {
    
    
    
    /** 收藏 */
    func collectPrepare(){
        
        let collectionBtn = CollectionBtn()
        collectionBtn.frame = CGRectMake(0, 0, 80, 30)
        collectionBtn.setTitle("收藏", forState: UIControlState.Normal)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: collectionBtn)
        
        collectionBtn.addTarget(self, action: "collectAction", forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    
    func collectAction(){
        
        if model.collect == 1{
        
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "您已收藏", duration: 2, allowEdit: false, beginBlock: nil, completeBlock:nil)
            return
        }
        
        
        let userModel = UserModel.readSingleModelForKey(nil)
    
        if userModel == nil {
            
            
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请先登陆", duration: 2, allowEdit: false, beginBlock: nil, completeBlock: { () -> Void in
                
                
                let loginVC = LoginVC.controllerInitWithNib() as! LoginVC
                loginVC.addDismissBarButton()
                loginVC.isDismissType = true
                
                let appNav = AppNavVC.rootVC(loginVC)
                
                self.presentViewController(appNav, animated: true, completion: nil)
                
            })
            
            return
        }
        
        
        let url = URL_COLLECTION.completeURL
        
        let params = ["token": userModel.token,"staffID": staffID,"type": meauType]
        println("meauType========\(meauType)")
        APPHttp.postUrl(url, params: params, target: self.view, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            CoreSVP.showSVPWithType(CoreSVPTypeSuccess, msg: "收藏成功", duration: 2, allowEdit: false, beginBlock: nil, completeBlock:nil)
            
        }, errorBlock: nil)
    }
}




