//
//  ServiceDetailVCSignNameView.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class SignNameView: UIView {
    
    @IBOutlet weak var mainLabel: UILabel!
    
    @IBOutlet weak var descLabel: UILabel!


}

extension SignNameView{
    
    class func quickView() -> SignNameView{
        
        return NSBundle.mainBundle().loadNibNamed("SignNameView", owner: nil, options: nil).last as! SignNameView
    }
    
}
