//
//  ServiceList.h
//  WelCome
//
//  Created by 冯成林 on 15/8/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"
#import "ServiceItemModel.h"


@interface ServiceListModel : BaseModel


@property (nonatomic,copy) NSString *name,*signature,*service_price,*sign,*truename,*photo;

@property (nonatomic,assign) NSInteger sex,age,star,for_vip,type;

@property (nonatomic,assign) double stature,weight;

@property (nonatomic,strong) NSArray *serviecArr;

@property (nonatomic,strong) NSArray *markArr;

@end
