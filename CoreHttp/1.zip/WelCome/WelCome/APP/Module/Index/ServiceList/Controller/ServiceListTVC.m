//
//  ServiceListTVC.m
//  WelCome
//
//  Created by 冯成林 on 15/8/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "ServiceListTVC.h"
#import "ServiceListModel.h"
#import "ServiceListCell.h"
#import "WelCome-Swift.h"
#import "UserModel.h"

@interface ServiceListTVC ()

@end

@implementation ServiceListTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorInset = UIEdgeInsetsZero;
    self.navigationItem.title = @"筛选结果";
}






-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    ServiceListModel *listModel = self.dataList[indexPath.row];
    
    ServiceDetailVC *detailVC = [[ServiceDetailVC alloc] initWithNibName: @"ServiceDetailVC" bundle:nil];
    
    detailVC.title = listModel.name;
    
    detailVC.meauType = self.meauType;
    
    detailVC.staffID = @(listModel.hostID);
    
    detailVC.beginTime = self.beginTime;
    detailVC.endTime = self.endTime;
    
    [self.navigationController pushViewController:detailVC animated:YES];
}




/** 协议方法区 */

/** 刷新方式 */
-(ListVCRefreshAddType)listVC_RefreshType{
    return ListVCRefreshAddTypeBoth;
}


/** 模型类 */
-(Class)listVC_Model_Class{
    return [ServiceListModel class];
}


/** 视图类 */
-(Class)listVC_View_Cell_Class{
    return [ServiceListCell class];
}

-(NSDictionary *)listVC_Request_Params{
    
    return self.params;
    
}


/** 是否移除回到顶部按钮 */
-(BOOL)listVC_Remove_Back2Top_Button{
    return NO;
}


/** tableViewController */
/** cell的行高：tableViewController专用 */
-(CGFloat)listVC_CellH4IndexPath:(NSIndexPath *)indexPath{
    return 58;
}

/** 无本地FMDB缓存的情况下，需要在ViewDidAppear中定期自动触发顶部刷新事件 */
-(NSString *)listVC_Update_Delay_Key{
    return NSStringFromClass(self.class);
}


/** 无缓存定期更新周期 */
-(NSTimeInterval)listVC_Update_Delay_Time{
    return 30;
}

/** 是否关闭返回顶部功能 */
-(BOOL)removeBack2TopBtn{
    return NO;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 105;
}

@end
