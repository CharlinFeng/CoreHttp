//
//  ServiceDetailVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit



class ServiceDetailVC: UIViewController,LCPanBackProtocol {
    
    var beginTime: String!
    var endTime: String!
    
    @IBOutlet weak var albumView: UIView!
    
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var mainImageV: ServiceDetailImageV!
    
    @IBOutlet var thunbnailImageVs: [ServiceDetailImageV]!
    
    var model: ServiceDetailModel!
    
    let tagContentView = UIView()
    let signView = SignNameView.quickView()
    let nameView = SignNameView.quickView()
    let recordView = ServiceRecordView.viewInitWithNib() as! ServiceRecordView
    let hobbyView = HobbyView.viewInitWithNib() as! HobbyView
    let expView = ExpView.viewInitWithNib() as! ExpView
    let certificateView = HobbyView.viewInitWithNib() as! HobbyView
    let locationView = HobbyView.viewInitWithNib() as! HobbyView
    
    var basicItems,certificateItems: [ServiceItemModel]!
    
    var staffID: NSNumber = 0
    
    var meauType: Int = 0
}


extension ServiceDetailVC{
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /** 收藏 */
        collectPrepare()
        
        /** 标签 */
        tagsPrepare()
        
        /** 个性签名+真实姓名 */
        signNameViewPrepare()
        
        /** 服务记录 */
        recordPrepare()
        
        /** 爱好准备 */
        hobbyPrepare()
        
        /** 个人履历 */
        expPrepare()
        
        /** 证书准备 */
        certificatePrepare()
        
        /** 地点准备 */
        locationViewPrepare()
        
        contentView.make_relation(sd: 2, v: locationView, vd: 2, o: -55)

        /** 处理数据 */
        dataPrepare()
        
        self.edgesForExtendedLayout = UIRectEdge.None
    }

    @IBAction func tapImageV(sender: UITapGestureRecognizer) {
        
        let index = sender.view!.tag
        
        var imageVArr = [mainImageV!]
        imageVArr += thunbnailImageVs!
        
        var hdURLS: [ServiceDetailModel.ImgData] = model.imgData
        hdURLS += model.otherImgData
    
        
        let huURLStrs = (hdURLS as NSArray).valueForKeyPath("photo") as! [String]

        let pbVC = PhotoBrowser()
        
        /**  设置相册展示样式  */
        pbVC.showType = PhotoBrowser.ShowType.ZoomAndDismissWithSingleTap
        
        /**  设置相册类型  */
        pbVC.photoType = PhotoBrowser.PhotoType.Host
        
        //强制关闭显示一切信息
        pbVC.hideMsgForZoomAndDismissWithSingleTap = true
        
        var models: [PhotoBrowser.PhotoModel] = []
        
        //模型数据数组
        for (var i=0; i<huURLStrs.count; i++){
            
            let model = PhotoBrowser.PhotoModel(hostHDImgURL:huURLStrs[i].resourceURL , hostThumbnailImg: imageVArr[i].image, titleStr: nil, descStr: nil, sourceView: imageVArr[i])
            models.append(model)
        }
        
        /**  设置数据  */
        pbVC.photoModels = models
        
        pbVC.show(inVC: self,index: index)
    }
    
    @IBAction func chooseAction(sender: AnyObject) {
        
        CoreSVP.showSVPWithType(CoreSVPTypeLoadingInterface, msg: nil, duration: 0, allowEdit: false, beginBlock: nil, completeBlock: nil)
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            
            let chooseVC = ChooseSVVC.controllerInitWithNib() as! ChooseSVVC
            chooseVC.model = self.model
            chooseVC.basicItems = self.basicItems
            chooseVC.certificateItems = self.certificateItems
            chooseVC.beginTime = self.beginTime
            chooseVC.endTime = self.endTime
            chooseVC.meauType = self.meauType
            CoreSVP.dismiss()
            self.navigationController?.pushViewController(chooseVC, animated: true)
        })
    }
    
    func enablePanBack(panNavigationController: LCPanNavigationController!) -> Bool {
        return false
    }
    
}
