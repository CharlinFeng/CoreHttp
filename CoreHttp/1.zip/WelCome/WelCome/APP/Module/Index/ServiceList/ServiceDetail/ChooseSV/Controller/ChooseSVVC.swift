//
//  ChooseSVVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ChooseSVVC: UIViewController,UITextViewDelegate,UITextFieldDelegate {
    
    var model: ServiceDetailModel!
    var cityModel: CFCityPickerVC.CityModel = AppCityModel.sharedInstance.currentCityModel
    var beginTime: String!
    var endTime: String!
    var meauType: Int = 0
    
    var userModel: UserModel? {return UserModel.readSingleModelForKey(nil)}
    
    
    var serviceContent: String!{didSet{serviceContentKVO()}}
    
    
    lazy var cityRow = {SearchItemRow.cityRow()}()
    lazy var dateRow = {SearchItemRow.dateRow()}()
    lazy var serviceRow = {SearchItemRow.cityRow()}()
    lazy var serviceItems = ["翻译","导游","商务/公关"]

    lazy var av = {AccessoryView.instance()}()
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var basicTagView: TagView!
    
    @IBOutlet weak var moreTagView: TagView!
    
    @IBOutlet weak var topContentView: UIView!
    
    @IBOutlet weak var textView: BaseTextView!
    
    @IBOutlet weak var headImageV: UIImageView!
    
    @IBOutlet weak var nickLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var bottomMarginVC: NSLayoutConstraint!
    
    var basicItems,certificateItems: [ServiceItemModel]!
    
    var selectedCity: String!
    
    @IBOutlet weak var callTF: UITextField!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "订单确认"
        
        headImageV.imageWithUrlStr(model.imgData[0].thumb_photo.resourceURL, phImage: nil)
        nickLabel.text = model.name
        nameLabel.text = model.truename
        basicTagView.serviceItemModels = basicItems
        moreTagView.serviceItemModels = certificateItems
        
        textView.setBorder(hexColor("b9b9b9"), width: 1.0)
        textView.radius = 4
        textView.placeholder = "给她留言"
 
        TextViewKeyBoardVC().avoid(inVC: self, scrollView: scrollView, textView: textView, offsetY: 0)
        
        
        /** 处理picker */
        pickerPrepare()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "userModelSetted", name: LoginSuccessNoti, object: nil)
        
        callTF.delegate = self
        
        let av2 = AccessoryView.instance()
        callTF.inputAccessoryView = av2
        av2.hideCancelBtn = true
        av2.doneBtnActionClosure = {[unowned self] in
            self.callTF.resignFirstResponder()
        }
        
        userModelSetted()
    }

    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            UIView.setAnimationCurve(UIViewAnimationCurve(rawValue: 7)!)
            self.view.transform = CGAffineTransformMakeTranslation(0, -200)
        })
        return true
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            UIView.setAnimationCurve(UIViewAnimationCurve(rawValue: 7)!)
            self.view.transform = CGAffineTransformIdentity
        })
        
        return true
    }
    

    deinit{NSNotificationCenter.defaultCenter().removeObserver(self)}
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        view.endEditing(true)
    }
    

    
    func userModelSetted(){
        
        callTF.text = userModel?.phone
    }
    
    
    @IBAction func submitOrder(){
        
        if selectedCity == nil {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请选取服务城市", duration: 2, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        
        
        if serviceContent == nil {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请选取服务内容", duration: 2, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        
        if !(callTF.text as NSString).isMobileNO{
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "手机格式有误", duration: 2, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        
        if userModel == nil {
            
            
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请先登陆", duration: 2, allowEdit: false, beginBlock: nil, completeBlock: { () -> Void in
                
                let loginVC = LoginVC.controllerInitWithNib() as! LoginVC
                loginVC.addDismissBarButton()
                loginVC.isDismissType = true
                
                let appNav = AppNavVC.rootVC(loginVC)
                
                self.presentViewController(appNav, animated: true, completion: nil)
                
            })
            
            return
        }
        
        
        let url = URL_SUBMIT_ORDER.completeURL
        
        let beginTimeStr = dateRow.beginTF.datePicker.selectedRealValue
        let endTimeStr = dateRow.endTF.datePicker.selectedRealValue
        
        var params = ["token": userModel!.token,"staffID":model.id,"type": meauType,"starTime": beginTimeStr,"endTime": endTimeStr,"contactPhone": "13540033473","address":selectedCity,"service": serviceContent]
        
        if textView.text != nil {
            params["message"] = textView.text
        }


        APPHttp.postUrl(url, params: params, target: self.view, type: APPHttpTypeSVP, success: { (data) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                let orderSVC = OrderSVC.controllerInitWithNib() as! OrderSVC
                
                let orderModel = OrderLModel(keyValues: data)
                orderSVC.orderLModel = orderModel
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    
                    self.navigationController?.pushViewController(orderSVC, animated: true)
                })
            })
            
        }, errorBlock: nil)
        
    }
    
}
