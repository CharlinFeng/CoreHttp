//
//  CollectionBtn.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class CollectionBtn: CoreBtn {
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        /** 视图准备 */
        self.viewPrepare()
    }
    


}





extension CollectionBtn{
    

    /** 视图准备 */
    func viewPrepare(){
        
        self.setImage(UIImage(named: "collect"), forState: UIControlState.Normal)
    
        self.titleEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 0)
        
        self.adjustsImageWhenHighlighted = false
        
        self.setTitleColor(UIColor.lightGrayColor(), forState: UIControlState.Highlighted)
    }
    
    
    
}