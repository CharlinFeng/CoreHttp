//
//  OrderSVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class OrderSVC: UIViewController {
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var label: UILabel!
    
    var orderLModel: OrderLModel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "下单成功"
        btn1.radius = 4
        btn2.radius = 4
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: UIView())
        
        let time = orderLModel.time.timestamp(format: "yyyy年MM月dd日")
        let beginTime = orderLModel.stime.timestamp(format: "yyyy-MM-dd")
        let endTime = orderLModel.etime.timestamp(format: "yyyy-MM-dd")
        label.text = "订单编号：\(orderLModel.order_no) \n订单时间：\(time) \n您选择了\(orderLModel.trueName)在\(beginTime)~\(endTime)向您提供\(orderLModel.service)服务,\(orderLModel.trueName)将很快与您联系！"
        
        (self.navigationController as! AppNavVC).canDragBack = false
    }

    @IBAction func toHome(sender: AnyObject) {
        
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func toOrder(sender: AnyObject) {
        
        let tabVC = self.navigationController?.parentViewController as! AppTabVC
        
        toHome(sender)
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,Int64(0.4 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), { () -> Void in
            tabVC.selectedIndex = 3
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,Int64(0.4 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), { () -> Void in
                
                let navVC = tabVC.selectedViewController as! AppNavVC
                
                let mineVC = navVC.viewControllers.first as! MineVC
                
                mineVC.toOrderListVC(sender as! UIButton)
            })
        })
    }
    
    
    
    
}
