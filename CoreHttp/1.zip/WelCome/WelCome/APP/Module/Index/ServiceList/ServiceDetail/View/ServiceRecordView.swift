//
//  ServiceRecordView.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ServiceRecordView: UIView {
    
    
    @IBOutlet weak var listLabel: UILabel!


}
