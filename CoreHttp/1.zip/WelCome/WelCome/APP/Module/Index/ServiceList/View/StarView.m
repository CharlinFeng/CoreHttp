//
//  StarView.m
//  Carpenter
//
//  Created by 冯成林 on 15/5/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "StarView.h"
#import "UIColor+Extend.h"
#import "UIImage+FixOrientation.h"


@implementation StarView

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if(self){
        
        //视图准备
        [self viewPrepare];
    }
    
    return self;
}


-(id)initWithCoder:(NSCoder *)aDecoder{
    
    self=[super initWithCoder:aDecoder];
    
    if(self){
        
        //视图准备
        [self viewPrepare];
    }
    
    return self;
}



/*
 *  视图准备
 */
-(void)viewPrepare{
    
    //基本颜色
    self.baseColor = [UIColor clearColor];
    
    //大小
    self.markFont = [UIFont systemFontOfSize:17];
    
    //选中图片
    self.markImage = [UIImage imageNamed:@"star"];
    
    //选中颜色
    self.highlightColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:@"star"] rotate:M_PI]];
    
    self.numberOfStar = 5;
    
    self.enabled = NO;
    
    
//    @property (nonatomic) NSUInteger numberOfStar;
//    @property (copy, nonatomic) NSString *markCharacter;
//    @property (strong, nonatomic) UIFont *markFont;
//    @property (strong, nonatomic) UIImage *markImage;
//    @property (strong, nonatomic) UIColor *baseColor;
//    @property (strong, nonatomic) UIColor *highlightColor;
//    @property (nonatomic) float value;
//    @property (nonatomic) float stepInterval;
//    @property (nonatomic) float minimumValue;
//    
}

@end
