//
//  ServiceDetailVC+Record.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension ServiceDetailVC{

    
    /** 服务记录 */
    func recordPrepare(){

        contentView.addSubview(recordView)
        
        recordView.snp_makeConstraints { (make) -> Void in
            
            make.top.equalTo(self.nameView.snp_bottom).offset(5)
            make.leading.equalTo(self.contentView.snp_leading)
            make.trailing.equalTo(self.contentView.snp_trailing)
        }
    }

    /** 服务记录 */
    func recordDataFill(model: ServiceDetailModel){
        
        if model.serviceRecord?.count == 0{recordView.make_height(equal: 50);return}
        
        var str = ""
        
        model.serviceRecord.enumerate { (index, value) -> Void in
            
            str += value.time.timestamp(format: "yyyy-MM-dd") + "         " + value.content + "\n"
        }
        
        recordView.make_height(equal: CGFloat(model.serviceRecord.count * 24 + 40))
        
        recordView.listLabel.text = str
        
        println("结果：\(str),\(model.serviceRecord)")
    }


}