//
//  ChooseSVVC+Main.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

class ServiceIM{
    
    var isChecked: Bool!
    var isRequired: Bool!
    var title: String!
    init(title: String,isRequired: Bool){
        self.title = title
        self.isRequired = isRequired
        self.isChecked = false
    }
    
    class func convert(models: [ServiceDetailModel.ServiceListArr]) -> [ServiceIM]{
        
        var arr: [ServiceIM] = []
        
        /** 数组遍历 */
        for (index: Int, s: ServiceDetailModel.ServiceListArr) in enumerate(models){
            
            let sim = ServiceIM(title: s.name!, isRequired: s.isRequired!.boolValue)
            if(s.isRequired!.boolValue) {sim.isChecked = true}
            arr.append(sim)
        }
        
        return arr
    }
    
}


extension ChooseSVVC: CFCityPickerVCDelegate{

    /** 处理picker */
    func pickerPrepare(){
        
        mainView.addSubview(cityRow)
        mainView.addSubview(dateRow)
        mainView.addSubview(serviceRow)
        serviceRow.showTF = true
        serviceRow.titleLabel.text = "服务内容"
        
        var itemH: CGFloat = 66
        
        if iPhone4x_320_480() {itemH = 56}
        let left: CGFloat = -12
        cityRow.make_topInsets_topHeight(top: 0, left: left, right: 0, topHeight: itemH)
        dateRow.make_topInsets_topHeight(top: itemH, left: left, right: 0, topHeight: itemH)
        serviceRow.make_topInsets_topHeight(top: itemH * 2, left: left, right: 0, topHeight: itemH)

        dateRow.beginTF.addKeyBoardTool(explain: "请选择开始时间")
        dateRow.endTF.addKeyBoardTool(explain: "请选择结束时间")
        
        //添加数据
        let sims = ServiceIM.convert(model.serviceListArr)

        serviceRow.tf.addMulSelWithModels(sims)
        
        serviceRow.tf.doneBtnClickClosure = {[unowned self] (all,sel) in
        
            if count(sel)==0{return}
            
            var str = ""
            /** 数组遍历 */
            for (index: Int, s: ServiceIM) in enumerate(sel){
                str = str + s.title + ","
            }
            
            var strM = NSMutableString(string: str)
            
             strM.deleteCharactersInRange(NSMakeRange(count(str) - 1, 1))
            
            self.serviceContent = strM as String
        }
        
        /** 事件 */
        itemRowAction()
        
        /** 数据填充 */
        dataFill()
    }
    
    func serviceContentKVO(){
        serviceRow.tf.text = serviceContent
    }
    
    
    
    func dataFill(){
        
        if beginTime != nil {
            
            let datePicker = dateRow.beginTF.datePicker
            let date = NSDate(timeIntervalSince1970: Double(beginTime.toInt()!))
            datePicker.setDate(date, animated: false)
            datePicker.selectedRealValue = beginTime
                
            dateRow.beginTF.text = beginTime.timestamp(format: "MM月dd日")
        
        }
        if endTime != nil {
        
            let datePicker = dateRow.endTF.datePicker
            let date = NSDate(timeIntervalSince1970: Double(endTime.toInt()!))
            datePicker.setDate(date, animated: false)
            datePicker.selectedRealValue = endTime
            dateRow.endTF.text = endTime.timestamp(format: "MM月dd日")
        }
        
        if beginTime != nil && endTime != nil{
            dateRow.calMinusDate()
        }
        
        
        if meauType != 0{
            serviceRow.locationBtn.setTitle(serviceItems[meauType-1], forState: UIControlState.Normal)
        }
    }
    
    
    
    /** 事件 */
    func itemRowAction(){
        
        
        /** 选择城市 */
        cityRow.selectCityClosure = { [unowned self] in
            
            self.view.endEditing(true)
            
            let cities = self.model.serviceCityArr.map{$0.name}
    
            CoreAleetViewManagerVC.showWithAleetViewType(CoreAleetViewTypeUIActionSheet, inController: self, title: "请选择城市", message: "", cancelButtonTitle: "取消", destructiveButtonTitle:nil, otherButtonTitles: cities, clickedButtonBlock: { (index) -> Void in
                
                let i = index==0 ? 0 : index-1
                
                self.selectedCity = cities[i]
                
                self.cityRow.locationBtn.setTitle(cities[i], forState: UIControlState.Normal)
                
            })
    
            
        }
        
        /** 选择服务项目 */
        serviceRow.selectCityClosure = { [unowned self] in
            
            self.view.endEditing(true)
            
            /** 滚动到最顶部 */
            self.scrollToTop()
            
            var items = self.serviceItems
            
            CoreAleetViewManagerVC.showWithAleetViewType(CoreAleetViewTypeUIActionSheet, inController: self, title: "请选择", message: "请选择", cancelButtonTitle: "取消", destructiveButtonTitle: nil, otherButtonTitles:items ) { (index) -> Void in
                
                println(index)
            }
            
        }
    }
    
    func selectedCity(cityModel: CFCityPickerVC.CityModel) {
        self.cityRow.serviceLocation = cityModel
        self.cityModel = cityModel
    }
    
    

    /** 滚动到最顶部 */
    func scrollToTop(){
        
        let height = topContentView.height + 10
    
        scrollView.setContentOffset(CGPointMake(0, height), animated: true)
    }
    

    
    
}

