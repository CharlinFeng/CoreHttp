//
//  ServiceHobbyView.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class HobbyView: UIView {

    @IBOutlet weak var tagView: TagView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var name: String! {didSet{nameLabel.text = name}}
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        tagView.needMultiRow = true
        
        tagView.maxWidth = Screen.width - 60
        
        tagView.fontPoint = 15
        
        tagView.margin = 8
        
        tagView.borderColor = AppConst.AppColor
        
        tagView.HeightCalBlock = {height in
        
            println("=====\(height)")
            self.make_height(equal: height + 60)
        }
    }
    
    

}
