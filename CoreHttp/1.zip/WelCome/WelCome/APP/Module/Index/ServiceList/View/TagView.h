//
//  TagView.h
//  WelCome
//
//  Created by 冯成林 on 15/8/17.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TagView : UIView

@property (nonatomic,assign) CGFloat margin;

@property (nonatomic,assign) CGFloat fontPoint;

@property (nonatomic,strong) NSArray *serviceItemModels;

@property (nonatomic,assign) BOOL needMultiRow;

@property (nonatomic,assign) CGFloat maxWidth;

@property (nonatomic,copy) void (^HeightCalBlock)(CGFloat height);

@property (nonatomic,strong) UIColor *borderColor;

@end
