//
//  ServiceDetailVC+Tags.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension ServiceDetailVC{

    /** 标签 */
    func tagsPrepare(){
        
        contentView.addSubview(tagContentView)
        tagContentView.backgroundColor = UIColor.whiteColor()
        tagContentView.make_relation(sd: 0, v: albumView, vd: 2, o: -5)
        tagContentView.make_relation(sd: 1, v: nil, vd: 1, o: 0)
        
        tagContentView.make_relation(sd: 3, v: nil, vd: 3, o: 0)
        
        let tagView = TagView()
        
        tagContentView.addSubview(tagView)
        tagContentView.make_relation(sd: 2, v: tagView, vd: 2, o: -13)
        //添加约束
        tagView.snp_makeConstraints {[unowned self] (make) -> Void in
            
            make.top.equalTo(self.tagContentView.snp_top).offset(13)
            make.leading.equalTo(tagView.superview!.snp_leading).offset(15)
            make.trailing.equalTo(tagView.superview!.snp_trailing).offset(15)
            
        }
        
        
        tagView.HeightCalBlock = {[unowned self] height in
            
            //添加约束
            tagView.snp_makeConstraints({ (make) -> Void in
                
                make.height.equalTo(height)
            })
            
        }
        
        //需要多行
        tagView.needMultiRow = true
        
        //最大宽度
        tagView.maxWidth = Screen.width - 30
        
        //间距
        tagView.margin = 8
        
        //字体
        tagView.fontPoint = 15
        
    }
    
    /** 展示tag数据 */
    func tagFill(model: ServiceDetailModel){
        
        
        let item1 = ServiceItemModel(name: model.name, bgColor: "ed788d")
        let item2 = ServiceItemModel(name: "\(model.age)", bgColor: "f8b325")
        let item3 = ServiceItemModel(name: "\(model.stature) cm", bgColor: "a2cb31")
        let item4 = ServiceItemModel(name: "\(model.weight) kg", bgColor: "e94e50")
        let item5 = ServiceItemModel(name: model.sign, bgColor: "0cb7d1")
    
        var items: [ServiceItemModel] = [item1,item2,item3,item4,item5]
        basicItems = items
        if model.serviceListArr != nil {
        
            model.serviceListArr.enumerate({ (index, value) -> Void in
                
                let item = ServiceItemModel(name: value.name, bgColor: value.bg_color)
                items.append(item)
            })
        
        }
        
        (tagContentView.subviews.first as! TagView).serviceItemModels = items
        
    }
    
}
