//
//  IndexMeauModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/15.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

class IndexMeauModel: BaseModel{
    
    let imageName: String
    let nameText: String
    let bgColor: String
    
    init(imageName: String, nameText: String, bgColor: String){
     
        self.imageName = imageName
        self.nameText = nameText
        self.bgColor = bgColor
    }
}