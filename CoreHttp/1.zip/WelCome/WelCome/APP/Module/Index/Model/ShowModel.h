//
//  ShowModel.h
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "BaseModel.h"

@interface ShowModel : BaseModel

@property (nonatomic,assign) NSInteger photoType,cityID,functionType;

@property (nonatomic,copy) NSString *link_url,*photo;


+(NSArray *)pptDataModel:(NSArray *)showModles;


@end
