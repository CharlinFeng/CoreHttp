//
//  ShowModel.m
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "ShowModel.h"
#import "WelCome-swift.h"

@implementation ShowModel


+(NSArray *)pptDataModel:(NSArray *)showModles{
    
    NSMutableArray *pptDataModels = [NSMutableArray arrayWithCapacity:showModles.count];
    
    //遍历
    [showModles enumerateObjectsUsingBlock:^(ShowModel *showModel, NSUInteger idx, BOOL *stop) {
        
        PPTDataModel *pptDataModel = [[PPTDataModel alloc] initWithNetworkImageUrl:showModel.photo.resourceURL placeHolderImage:nil titleStr:@"名字" model: showModel];
        
        
        [pptDataModels addObject:pptDataModel];
    }];
    
    
    return pptDataModels;
}




/*
 *  协议方法区
 */


/** 普通模型代理方法区 */

/** 接口地址 */
+(NSString *)baseModel_UrlString{

    return AppConst.IndexShow.completeURL;
}

/** 请求方式 */
+(BaseModelHttpType)baseModel_HttpType{
    return BaseModelHttpTypePOST;
}

/** 是否需要本地缓存 */
+(BOOL)baseModel_NeedFMDB{
    return NO;
}

/** 缓存周期：单位秒 */
+(NSTimeInterval)baseModel_Duration{
    return 1;
    return 24 * 60;
}

/**
 *  错误数据解析：请求成功，但服务器返回的接口状态码抛出错误
 *
 *  @param hostData 服务器数据
 *
 *  @return 如果为nil，表示无错误；如果不为空表示有错误，并且为错误信息。
 */
+(NSString *)baseModel_parseErrorData:(NSDictionary *)hostData{
    
    NSString *msgOut = hostData[@"msg"];
    
    NSString *msgIn = hostData[@"data"][@"dataMsg"];
    
    NSString *msg = nil;
    
    if(![msgIn isEqualToString:@"ok"]) msg = msgIn;
    
    if(![msgOut isEqualToString:@"ok"]) msg = msgOut;
    
    return msg;
}

/** 服务器真正有用数据体：此时只是找到对应的key，还没有字典转模型 */
+(id)baseModel_findUsefullData:(NSDictionary *)hostData{
    return hostData[@"data"][@"dataData"];
}

/** 返回数据格式 */
+(BaseModelHostDataType)baseModel_hostDataType{
    return BaseModelHostDataTypeModelArray;
}




/** 分页模型代理方法区 */


/**
 *  是否为分页数据
 *
 *  @return 如果为分页模型请返回YES，否则返回NO
 */
+(BOOL)baseModel_isPageEnable{
    return NO;
}
//@property (nonatomic,assign) NSInteger photoType,cityID,functionType;
//
//@property (nonatomic,copy) NSString *link_url,*photo;
-(NSString *)description{
    
    return [NSString stringWithFormat:@"photoType=%@,cityID=%@,functionType=%@,link_url=%@,photo=%@,hostID=%@",@(self.photoType),@(self.cityID),@(self.functionType),self.link_url,self.photo,@(self.hostID)];
}

@end
