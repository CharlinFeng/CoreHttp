//
//  MeauEnterVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/18.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class MeauEnterVC: UIViewController {
    
    var meauType: MeauType!
    
    var cityRow: SearchItemRow = SearchItemRow.cityRow()
    var dateRow: SearchItemRow!
    var langRow: SearchItemRow!
    
    @IBOutlet weak var signImageV: UIImageView!
    
    
    @IBOutlet weak var topContentView: UIView!
    
    @IBOutlet weak var topContentViewHC: NSLayoutConstraint!
}




