//
//  SearchItemRow.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/18.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class SearchItemRow: UIView,UITextFieldDelegate {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var locationBtn: UIButton!
    @IBOutlet weak var beginTF: UITextField!
    @IBOutlet weak var endTF: UITextField!
    
    @IBOutlet weak var lang1TF: UITextField!
    @IBOutlet weak var lang2TF: UITextField!
    
    @IBOutlet weak var endLabel: UILabel!
    
    @IBOutlet weak var tf: MulSelTF!
    
    var showTF: Bool = false {didSet{showTFKVO()}}
    
    var isExchanged: Bool = false
    
    var serviceLocation: CFCityPickerVC.CityModel!{didSet{locationBtn.setTitle(serviceLocation.name, forState: UIControlState.Normal)}}
    var selectCityClosure: (()->Void)!
    var selectDateClosure:((btn: UIButton)->Void)!
    var langModels: [LangModel]!{didSet{langPrepare()}}
    
    var beginTime: String! {
    
        return beginTF.datePicker.selectedRealValue
    }
    
    
    var endTime: String!{
        return endTF.datePicker.selectedRealValue
    }
    
    var lang1ID: String!{
    
        return isExchanged ? lang2TF.input1pickerView.selectedRealValue : lang1TF.input1pickerView.selectedRealValue
    }
    
    var lang2ID:  String!{
        
        return isExchanged ? lang1TF.input1pickerView.selectedRealValue : lang2TF.input1pickerView.selectedRealValue
    }
    
    
    func showTFKVO(){
    
        locationBtn.hidden = true
        tf.hidden = false
    }
    
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        addLine()
        addArrow()
        
        let datePicker1 = CoreDatePicker("MM-dd")
        datePicker1.datePickerMode = UIDatePickerMode.Date
        beginTF?.addDatePickerView(datePicker1)
        
        let datePicker2 = CoreDatePicker("MM-dd")
        datePicker2.datePickerMode = UIDatePickerMode.Date
        endTF?.addDatePickerView(datePicker2)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "calMinusDate", name: "pickerViewDidSelectedValue", object: nil)
        
    }
    
    deinit{
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    
    /** 城市 */
    class func cityRow()->SearchItemRow{
        
        let itemRow = NSBundle.mainBundle().loadNibNamed("SearchItemRow", owner: nil, options: nil).first as! SearchItemRow
        
        return itemRow
    }
    
    /** 日期 */
    class func dateRow()->SearchItemRow{
        
        let itemRow = NSBundle.mainBundle().loadNibNamed("SearchItemRow", owner: nil, options: nil)[1] as! SearchItemRow
        
        return itemRow
    }
    
    /** 语言 */
    class func langRow()->SearchItemRow{
        
        let itemRow = NSBundle.mainBundle().loadNibNamed("SearchItemRow", owner: nil, options: nil)[2] as! SearchItemRow
        
        return itemRow
    }
    
}

extension SearchItemRow {
    

    func addLine(){
        
        let lineView = UIView()
        lineView.backgroundColor = hexColor("dededf")
        self.addSubview(lineView)
        lineView.make_bottomInsets_bottomHeight(left: 14, bottom: 0, right: 14, bottomHeight: 1)
        
    }
    
    func addArrow(){
        
        //右边的前头
        let img = UIImage(named: "return")?.imageWithGradientTintColor(AppConst.AppColor).rotate(CGFloat(M_PI))
        
        let imageV = UIImageView(image: img)
        
        self.addSubview(imageV)
        
        imageV.make_right_WH(right: 30, offsetY: 0, width: 9, height: 16)
    }
    
    @IBAction func SelectCityAction(sender: AnyObject) {
        
        selectCityClosure?()
    }


    func calMinusDate(){
        
        if endLabel == nil {return}
        
        if beginTime == nil {return}
        if endTime == nil {return}
        
        let day: Int = (endTime.toInt()! - beginTime.toInt()!) / (3600 * 24)
        
        endLabel.text = "结束 共\(day)天"
    }

    
    func langPrepare(){
        
        var items: [Core1KeyValueObj] = []
        
        /** 数组遍历 */
        for (index: Int, langModel: LangModel) in enumerate(langModels){
            
            let item = Core1KeyValueObj.modelWithObj(langModel.id.integerValue, content: langModel.name!)
            
            items.append(item)
        }
        
        //建立模型
        let pickerModel = Core1PickerModel(items)
        
        //建立pickerView
        let pickerView1 = Core1PickerView(pickerModel)
        
        //建立pickerView
        let pickerView2 = Core1PickerView(pickerModel)
        
        //执行添加
        lang1TF.add1PickerView(pickerView1)
        lang2TF.add1PickerView(pickerView2)
    }
    
    @IBAction func exchange(sender: AnyObject) {
        
        isExchanged = !isExchanged
        let tempText = lang1TF.text
        lang1TF.text = lang2TF.text
        lang2TF.text = tempText
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        
        self.endEditing(true)
    }

}
