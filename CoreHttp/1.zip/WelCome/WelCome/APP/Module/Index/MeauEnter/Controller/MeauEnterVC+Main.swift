//
//  MeauEnterVC+Main.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/18.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation


extension MeauEnterVC: CFCityPickerVCDelegate{
    

    override func viewDidLoad() {
        super.viewDidLoad()

        dateRow = SearchItemRow.dateRow()
        
        topContentView.addSubview(cityRow)
        topContentView.addSubview(dateRow)
        
        dateRow.beginTF.addKeyBoardTool(explain: "请选择开始时间")
        dateRow.endTF.addKeyBoardTool(explain: "请选择结束时间")
        
        var itemH: CGFloat = 66
        
        if iPhone4x_320_480() {itemH = 56}
        
        cityRow.make_topInsets_topHeight(top: 0, left: 0, right: 0, topHeight: itemH)
        dateRow.make_topInsets_topHeight(top: itemH, left: 0, right: 0, topHeight: itemH)
        
        if meauType == MeauType.Translation {
            
            langRow = SearchItemRow.langRow()
            topContentView.addSubview(langRow)
            langRow.make_topInsets_topHeight(top: itemH * 2, left: 0, right: 0, topHeight: itemH)

            langRow.lang1TF.addKeyBoardTool(explain: "请选择原始语言")
            langRow.lang2TF.addKeyBoardTool(explain: "请选择翻译语言")
            
            /** 请求数据 */
            LangModel.getData({ (langModels) -> Void in
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    
                    CoreViewNetWorkStausManager.dismiss(self.view, animated: true)
                    
                    self.langRow.langModels = langModels
                })
            }, target: self.view)

        }else{
            
            topContentViewHC.constant = itemH * 2
            
            if meauType == MeauType.VIP{signImageV.hidden = false}
        }
        
        /** 事件 */
        itemRowAction()
    }
    

    /** 事件 */
    func itemRowAction(){
        
        /** 选择城市 */
        cityRow.selectCityClosure = { [unowned self] in
            
            self.view.endEditing(true)
        
            let appCityModel = AppCityModel.sharedInstance
            
            let cityVC = CFCityPickerVC()
        
            cityVC.delegate = self

            //解析字典数据
            let cityModels = appCityModel.cityModels
            cityVC.cityModels = cityModels
            
            //设置当前城市
            cityVC.currentCity = "成都"
            
            //设置热门城市
            cityVC.hotCities = ["北京","上海","广州","成都","杭州","重庆"]
            
            let navVC = AppNavVC(rootViewController: cityVC)
            
            self.presentViewController(navVC, animated: true, completion: nil)
        }

    }
    
    func selectedCity(cityModel: CFCityPickerVC.CityModel) {
        self.cityRow.serviceLocation = cityModel
    }
    
    
    
    @IBAction func searchAction(sender: AnyObject) {
        
        if cityRow.serviceLocation == nil {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请选择城市", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        
        if dateRow.beginTime == nil || dateRow.endTime == nil {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请选择起始时间", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        
        if dateRow.beginTF.datePicker.selectedRealValue! > dateRow.endTF.datePicker.selectedRealValue! {
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "结束时间小于开始时间", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
            return
        }
        

        if meauType == MeauType.Translation{
            
            if langRow?.lang1TF.input1pickerView.selectedUIValue?.length < 1 || langRow?.lang2TF.input1pickerView.selectedUIValue?.length < 1 {
                CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "请选择语言", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
                return
            }
            
            if langRow?.lang1TF.input1pickerView.selectedUIValue == langRow?.lang2TF.input1pickerView.selectedUIValue{
                CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "语言不能一样", duration: 2.0, allowEdit: false, beginBlock: nil, completeBlock: nil)
                return
            }
        }
        
        
        view.endEditing(true)
        
        var params: [NSObject: AnyObject] = [:]
        
        //城市
        params["cityID"] = cityRow.serviceLocation.id
        
        //时间
        params["starTime"] = dateRow.beginTime
        params["endTime"] = dateRow.endTime
        
        if meauType == MeauType.Translation {
            
            //语言
            params["starLanguageID"] = langRow.lang1ID
            params["endLanguageID"] = langRow.lang2ID
        }

        params["type"] = meauType.rawValue + 1
        
        let serviceListTVC = ServiceListTVC()
        serviceListTVC.meauType = meauType.rawValue + 1
        serviceListTVC.params = params
        serviceListTVC.beginTime = dateRow.beginTime
        serviceListTVC.endTime = dateRow.endTime
        
        self.navigationController?.pushViewController(serviceListTVC, animated: true)
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        view.endEditing(true)
    }
    
}