//
//  LangModel.swift
//  WelCome
//
//  Created by 冯成林 on 15/8/24.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class LangModel: Reflect {
   
    var id: NSNumber!
    var name: String!
}


extension LangModel{
    
    /** 请求数据 */
    static func getData(dataClosure: (langModels: [LangModel]) -> Void, target: AnyObject!){
        
        let url = URL_LANG.completeURL
        
        APPHttp.postUrl(url, params: nil, target: target, type: APPHttpTypeStatusView, success: { data in
            
            //解析数据
            let langModels = LangModel.parses(arr: data as! NSArray) as! [LangModel]
        
            dataClosure(langModels: langModels)
            
        }, errorBlock: nil)
        
    }
    
    
}
