//
//  IndexVC.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit




class IndexVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var cityBtn: CityButton!

    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.title = "首页"
        
        //禁止延展布局
        self.edgesForExtendedLayout = UIRectEdge.None
       
        cityListen()

        /** 底部广告 */
        self.bottomAds()
        
        /** 处理collectionView */
        self.collectionViewPrepare()
        
        /** NavBar */
        navBarPrepare()
        
        //监听城市
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "cityListen", name: AppCityModelGetedCityNoti, object: nil)
        
        defaultCity()
        
        let appLocation = AppCityModel.sharedInstance
        
        appLocation.getCurrentCityModel()
    }
    
    
    func defaultCity(){
        
        let cd = CFCityPickerVC.CityModel(id: 2182, pid: 2181, name: "成都", spell: "ChendDu")
        
        let userInfo = ["cityModel": cd]
        
        NSNotificationCenter.defaultCenter().postNotificationName(AppCityModelGetedCityNoti, object: nil, userInfo: userInfo)
    }
    
    /** 监听 */
    func cityListen(){
        
        /** 加载幻灯数据 */
        self.showModelPrepare()
    }
    

    

}
