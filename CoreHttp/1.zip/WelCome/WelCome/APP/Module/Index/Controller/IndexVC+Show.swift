//
//  IndexVC+Extend.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/13.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation



/** 首页幻灯展示 */
extension IndexVC{
    
    /** 加载幻灯数据 */
    func showModelPrepare(){
        
        for view in self.topView.subviews {
            (view as! UIView).removeFromSuperview()
        }
        
        let appCityModel = AppCityModel.sharedInstance
        
        //加载数据
        var params = ["cityID":appCityModel.currentCityModel.id,"functionType":"1"]
        
        ShowModel.selectWithParams(params as [NSObject : AnyObject], userInfo: nil, beginBlock: { (isNetWorkRequest, needHUD) -> Void in
            
                println("请求开始")
            
            }, successBlock: {[unowned self] (models, sourceType, userInfo) -> Void in
            
                var pptView: CFPPTView = CFPPTView(type: PPTType.netWork, dataModels: { () -> [PPTDataModel] in
                    
                    return ShowModel.pptDataModel(models) as! [PPTDataModel]
                })
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
            
                    self.topView.addSubview(pptView)
                    
                    pptView.make_4Insets(UIEdgeInsetsZero)
                    
                    //事件
                    pptView.clickImageV = {(index , pptDataModel) -> Void in
                        
                        //取出模型
                        let showModel: ShowModel = pptDataModel.model! as! ShowModel
                        
                        var isWeb =  showModel.photoType == 2
                        
                        isWeb = showModel.link_url != nil
                        
                        if !isWeb {return}
                        
                        /** 展示网页 */
                        self.showWebVC(showModel)
                    }

                })
                
                
            }) { (errorResult, userInfo) -> Void in
                
                println("请求失败")
            }
  
    }
    

    /** 底部广告 */
    func bottomAds(){
        
        let indexAdsView = IndexAdsView.viewFromXIB()
        
        //添加
        bottomView.addSubview(indexAdsView)
        indexAdsView.make_4Insets(UIEdgeInsetsZero)
        
        var params = ["cityID":"2182","functionType":"2"]
        
        //传递数据
        ShowModel.selectWithParams(params, userInfo: nil, beginBlock: { (isNetWorkRequest, needHUD) -> Void in
            
            println("请求开始")
            
            }, successBlock: {[unowned self] (models, sourceType, userInfo) -> Void in
                
                if models == nil {return}
                
                indexAdsView.models = models as! [ShowModel]
                
            }) { (errorResult, userInfo) -> Void in
                
                println("请求失败")
                
        }

        
        indexAdsView.btnClickClosure = {(index, showModel) -> Void in
        
            /** 展示网页 */
            self.showWebVC(showModel)

        }
    }
    
    /** 展示网页 */
    func showWebVC(showModel: ShowModel){

        let webVC = SVWebViewController(address: showModel.link_url)
        
        webVC.addDismissBarButton()
        
        let webVCNavVC =  AppNavVC(rootViewController: webVC)
        
        
        self.presentViewController(webVCNavVC, animated: YES, completion: nil)
    }

}