//
//  IndexVC+Meau.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/15.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//


import UIKit


/** 处理菜单 */
extension IndexVC{
    
    var rid: String{
        return "IndexMeauCell"
    }
    
    /** 菜单数据 */
    var meauModels: [IndexMeauModel] {
        
        let m1 = IndexMeauModel(imageName: "translate", nameText: "翻译", bgColor: "ed788d")
        let m2 = IndexMeauModel(imageName: "guide", nameText: "本地导游", bgColor: "0cb7d1")
        let m3 = IndexMeauModel(imageName: "business", nameText: "商务/公关", bgColor: "308ece")
        let m4 = IndexMeauModel(imageName: "VIP", nameText: "VIP", bgColor: "f8b325")
        
        return [m1,m2,m3,m4]
    }
    
    /** 处理collectionView */
    func collectionViewPrepare(){
        
        //指定布局
        collectionView.collectionViewLayout = MeauLayout()
        
        //注册cell
        collectionView.registerNib(UINib(nibName: rid, bundle: nil), forCellWithReuseIdentifier: rid)
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    
    /** 协议方法区 */
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return meauModels.count
    }
    
    /** cell */
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        //取出cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(rid, forIndexPath: indexPath) as! IndexMeauCell
        
        //设置数据
        cell.baseModel = meauModels[indexPath.item]
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            
            let meauEnterVC = MeauEnterVC.controllerInitWithNib() as! MeauEnterVC
            meauEnterVC.title = self.meauModels[indexPath.item].nameText
            meauEnterVC.meauType = MeauEnterVC.MeauType(rawValue: indexPath.item)
            self.navigationController?.pushViewController(meauEnterVC, animated: true)
        })
        
    }
    
    
}