//
//  IndexVC+NavBar.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension IndexVC{
    
    
    /** NavBar */
    func navBarPrepare(){
        
        
        /** 城市按钮 */
        
        let cityBtn = CityButton()
        self.cityBtn = cityBtn
        cityBtn.frame = CGRectMake(0, 0, 62, 18)
        cityBtn.addTarget(self, action: "chooseCity", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: cityBtn)

        /** 信息按钮 */
        let messageBtn = MessageBtn()
        messageBtn.addTarget(self, action: "readMessage", forControlEvents: UIControlEvents.TouchUpInside)
        messageBtn.frame = CGRectMake(0, 0, 40, 18)
        self.navigationItem.rightBarButtonItem =  UIBarButtonItem(customView: messageBtn)
        
        /** 搜索框 */
        let searchBar = SearchBar()
        
        searchBar.addKeyBoardTool(explain: "请输入您想搜素的关键字")
        
        //事件
        searchBar.searchClosure = {[unowned self] (var searchText) in

            self.navigationController?.navigationBar.endEditing(YES)
        
            let serviceListVC = ServiceListTVC()
            
            let cityModel = AppCityModel.sharedInstance.currentCityModel
            
            let cityID=cityModel.id
                
            let dict = ["type":0,"cityID":cityID,"likeName":searchText]
      
            serviceListVC.params = ["type":0,"cityID":cityID,"likeName":searchText]
        
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                self.navigationController?.pushViewController(serviceListVC, animated: YES)
            })
            

        }
        
        searchBar.frame = CGRectMake(0, 0, 210, 44)
        self.navigationItem.titleView = searchBar
    }
    
    /** 选取城市 */
    func chooseCity(){
        self.navigationController?.navigationBar.endEditing(YES)
        
        let appCityModel = AppCityModel.sharedInstance
        
        let cityVC = CFCityPickerVC()
        
        //解析字典数据
        let cityModels = appCityModel.cityModels
        cityVC.cityModels = cityModels
        
        //设置当前城市
        cityVC.currentCity = "成都"
        
        //设置热门城市
        cityVC.hotCities = ["北京","上海","广州","成都","杭州","重庆"]
        
        let navVC = AppNavVC(rootViewController: cityVC)

        self.presentViewController(navVC, animated: true, completion: nil)
        
        //选中了城市
        cityVC.selectedCityModel = {[unowned self] (cityModel: CFCityPickerVC.CityModel) in
            
            appCityModel.currentCityModel = cityModel
        }
    }
    
    
    /** 查看信息 */
    func readMessage(){
        self.navigationController?.navigationBar.endEditing(YES)
        
        let userModel = UserModel.readSingleModelForKey(nil)
        
        if userModel == nil {
        
            CoreSVP.showSVPWithType(CoreSVPTypeError, msg: "您未登陆", duration: 2.0, allowEdit: NO, beginBlock: nil, completeBlock: { () -> Void in
                
                let loginVC = LoginVC.controllerInitWithNib() as! LoginVC
                loginVC.addDismissBarButton()
                loginVC.isDismissType = true
                
                let appNav = AppNavVC.rootVC(loginVC)
                
                self.presentViewController(appNav, animated: true, completion: nil)
            })
        
            return
        }
        
        let msgVC = MsgVC()
        
        self.navigationController?.pushViewController(msgVC, animated: YES)
    }
    

}