//
//  FavoritesVC.m
//  WelCome
//
//  Created by 冯成林 on 15/8/28.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "FavoritesVC.h"
#import "UserModel.h"
#import "WelCome-Swift.h"
#import "ServiceListCell.h"
#import "ServiceListModel.h"
#import "UIView+Masony.h"
#import "UIView+Extend.h"
#import "CoreViewNetWorkStausManager.h"

@interface FavoritesVC ()

@property (nonatomic,strong) UIView *bedView;

@end

@implementation FavoritesVC





-(void)viewDidLoad{
    
    [super viewDidLoad];
    
    self.navigationItem.title = @"我的收藏";
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadData) name:@"LoginSuccessNoti" object:nil];
    
    
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    UserModel *um = [UserModel readSingleModelForKey:nil];
    
    BOOL isOff = um == nil;
    
    self.offHttpRequest = isOff;
    
    if(!isOff){
        [super viewWillAppear:animated];
        [self loadData];
    }
    
    
    
    [self showOrDismissMaskView];
}



-(void)showOrDismissMaskView{
    
    UserModel *um = [UserModel readSingleModelForKey:nil];
    
    if(um == nil){
        [CoreViewNetWorkStausManager show:self.view type:CMTypeNormalMsgWithImage msg:@"您未登陆" subMsg:@"登陆查看收藏数据" offsetY:0 failClickBlock:nil];
    }
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ServiceListCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    
    cell.ClickCancelBtnBlock = ^(BaseModel *listModel){
        
        ServiceListModel *m = (ServiceListModel *)listModel;
        
        [self cancelOrder:m];
    };
    
    cell.showCancelBtn = YES;
    
    return cell;
}


-(void)cancelOrder:(ServiceListModel *)model{
    
    NSString *url = @"http://211.149.151.92/lailai/MyApi/cancelCollect";
    
    UserModel *userModel = [UserModel readSingleModelForKey:nil];
    
    NSDictionary *params = @{@"token": userModel.token,@"staffID": @(model.hostID)};
    
    [APPHttp postUrl:url params:params target:self.view type:APPHttpTypeSVP success:^(id obj) {
        
        [CoreSVP showSVPWithType:CoreSVPTypeSuccess Msg:@"取消成功" duration:2.0 allowEdit:NO beginBlock:nil completeBlock:^{
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self headerRefreshAction];
            });
            
        }];
        
    } errorBlock:nil];
}



-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)loadData{
    
    UserModel *userModel = [UserModel readSingleModelForKey:nil];
    
    if (userModel != nil) {
        
        self.params = @{@"type":@5,@"token":userModel.token};
    }
    
    [self headerRefreshAction];
}


-(UIView *)bedView{
    
    if(_bedView == nil){
        
        _bedView = [[UIView alloc] init];
    }
    return _bedView;
}


@end
