//
//  AppDelegate.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        /** 扩展AppDelegate的window初始化 */
        self.appDelegatePrepare()
        
        /** 集成功能 */
        umengSetup()
        
        return true
    }

}

