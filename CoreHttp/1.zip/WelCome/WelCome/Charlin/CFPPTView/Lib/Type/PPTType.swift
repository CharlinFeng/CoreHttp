//
//  PPTType.swift
//  CFPPTView
//
//  Created by 成林 on 15/6/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

enum PPTType{
    
    //本地相册
    case local
    
    //网络相册
    case netWork
    
}
