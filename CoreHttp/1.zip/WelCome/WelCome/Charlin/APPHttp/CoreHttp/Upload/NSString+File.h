//
//  NSString+File.h
//  Upload
//
//  Created by muxi on 15/2/12.
//  Copyright (c) 2015年 muxi. All rights reserved.
//  字符串数据转data，和文件操作无关

#import <Foundation/Foundation.h>

@interface NSString (File)


/**
 *  字符串转data
 */
-(NSData *)strData;







@end
