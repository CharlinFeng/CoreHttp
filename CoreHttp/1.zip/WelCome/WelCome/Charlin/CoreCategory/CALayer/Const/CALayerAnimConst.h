//
//  CALayerAnimConst.h
//  CoreCategory
//
//  Created by 冯成林 on 15/5/26.
//  Copyright (c) 2015年 沐汐. All rights reserved.
//

#ifndef _CALayerAnimConst_H_
#define _CALayerAnimConst_H_
#import <Foundation/Foundation.h>


/** x */
extern NSString *const KeyPath_TRANSFORM_TRANSLATION_X;

/** y */
extern NSString *const KeyPath_TRANSFORM_TRANSLATION_Y;


























#endif