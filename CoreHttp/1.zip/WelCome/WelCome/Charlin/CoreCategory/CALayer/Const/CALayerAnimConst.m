//
//  CALayerAnimConst.m
//  CoreCategory
//
//  Created by 冯成林 on 15/5/26.
//  Copyright (c) 2015年 沐汐. All rights reserved.
//


#ifndef _CALayerAnimConst_M_
#define _CALayerAnimConst_M_
#import <Foundation/Foundation.h>


/** x */
NSString *const KeyPath_TRANSFORM_TRANSLATION_X = @"transform.translation.x";


/** y */
NSString *const KeyPath_TRANSFORM_TRANSLATION_Y = @"transform.translation.y";

























#endif