//
//  UIImage+FixOrientation.h
//  image
//
//  Created by muxi on 14/11/12.
//  Copyright (c) 2014年 muxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (FixOrientation)

-(UIImage *)fixOrientation;

/** 图片旋转，返回一个新的旋转过的图片 */
-(UIImage *)rotate:(CGFloat)angle;

@end
