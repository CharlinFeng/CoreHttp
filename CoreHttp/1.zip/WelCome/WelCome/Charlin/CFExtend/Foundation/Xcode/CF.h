//
//  CF.h
//  CFPPTView
//
//  Created by 成林 on 15/6/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//


/**

$(SRCROOT)： 工程路径
$(TARGET_NAME)： 工程内层文件夹


 
 
 
 
 
 
 Git的使用：
 
 
 
 一、项目初始化：
 
 1.OSChina创建Git项目，获取git地址。
 
 2.进入项目目录，打开终端，进行git初始化。
 
 3.添加远程git地址，并起一个别名：
 git remote add [shortname] [url]
 
 4.查看远程地址：
 git remote
 
 4.本地提交git：
 git add .
 git commit -m "第一次提交项目"
 
 5.向远程git提交：
 git push [remote-name] [branch-name]
 比如：git push WelCome master
 
 二、常规提交：
 
 重复以上最后两步即可。
 
 
 
 
 
 
 
 
 





*/

