//
//  MaskViewAnimView.h
//  CoreBtn
//
//  Created by 成林 on 15/4/18.
//  Copyright (c) 2015年 沐汐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MaskViewAnimView : UIView




/*
 *  显示
 */
-(void)show:(UIView *)view;





@end
