//
//  UIView+CoreBtnExtend.h
//  CoreBtn
//
//  Created by 成林 on 15/4/19.
//  Copyright (c) 2015年 沐汐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (CoreBtnExtend)



/*
 *  给指定view添加一个和父控件一样大的约束
 */
-(void)constraintAdd;

@end
