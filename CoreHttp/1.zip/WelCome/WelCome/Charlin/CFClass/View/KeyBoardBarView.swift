//
//  KeyBoardBarView.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/27.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class KeyBoardBarView: UIView {

    var clickItemClosure: ((btn: UIButton,index: Int) -> Void)!
    
    
    @IBAction func clickItem(sender: UIButton) {
        
        if clickItemClosure != nil {clickItemClosure(btn: sender,index: sender.tag)}
    }
    
    
}
