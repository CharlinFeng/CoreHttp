//
//  AppDelegate+Umeng.swift
//  WelCome
//
//  Created by 冯成林 on 15/7/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension AppDelegate{
    
    /** 集成功能 */
    func umengSetup(){
        
        //设置AppKey
        CoreUMeng.umengSetAppKey(UmengAppKey)
        
        //集成新浪
        CoreUMeng.umengSetSinaSSOWithRedirectURL(SinaRedirectURL)
        
        //集成微信
        CoreUMeng.umengSetWXAppId(WXAppID, appSecret: WXAPPsecret, url: WXRedirectURL)

        //集成QQ
        CoreUMeng.umengSetQQAppId(QQAppID, appSecret: QQAPPsecret, url: QQRedirectURL)
    }
    
    /** 处理第三方 */
    func application(application: UIApplication, handleOpenURL url: NSURL) -> Bool {
        return CoreUMeng.umengHandleOpenURL(url)
    }
    
    /** 打开URL */
    func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject?) -> Bool {
        return CoreUMeng.umengHandleOpenURL(url)
    }
    
    
}






